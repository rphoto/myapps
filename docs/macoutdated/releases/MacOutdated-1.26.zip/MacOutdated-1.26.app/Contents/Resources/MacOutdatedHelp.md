# What MacOutdated Does

MacOutdated scans the apps installed on your Mac and compares the installed version to the newest version it can find from the app's update source.

It focuses on practical update checking for the kinds of apps people actually have installed:

- **Mac App Store apps**
- **Sparkle-based apps**
- **Apps with known API endpoints**
- **Apps whose version has to be read from a web page**
- **Apps that fall back to the Homebrew cask catalog**

# How It Works

MacOutdated starts by scanning common application folders on disk and reading each app bundle.

For each app it tries to determine:

- the app name
- the installed version
- the bundle identifier
- the update source
- the latest available version

It then groups apps into practical categories:

- **Outdated — App Store**
- **Outdated — Other**
- **Adobe Creative Cloud**
- **Unknown**
- **Up To Date**

This is not just a static report. The main window is designed to help you work through updates, confirm what changed, and inspect the source data when something looks wrong.

# Normal Workflow

## 1. Run a Scan

Review the MacOutdated main window. It will list all the apps after it scans for changes. That process should take no more than a minute and you can watch the progress bar.

MacOutdated will:

- scan installed apps
- check known update sources
- compare installed and latest versions
- look for system log entries that give us a hint about App Store (only) application updates
- group results in the main view

## 2. Review the Results

Start with the **Outdated** sections.

- **App Store apps** can usually be opened directly in the App Store update flow.
- **Sparkle apps** will have an "Update" button on the far right that you can click to update via the Sparkle framework.
- **Other apps** will have the ability for you to "Open" the app. At that point you have to figure out how to update that app. Maybe it is in a "Check for updates" menu item, maybe it is in the About box, maybe it just magically updates itself if you leave it alone and just restart the app after some number of minutes (allow time to download and install).
- **Unknown** means MacOutdated could not determine a trusted latest version from the available metadata.

- **Updated** in green with a checkmark appears when this app notices that the app has been updated, independent of how that happened (manual update by you, automatically or via Sparkle, for example).

## 3. Click an App Name for Details

Many clickable app names open an **App Details** view. You only have to do this when you expect an update but don't see one.

Use that page to inspect:

- installed version
- latest version
- release date
- source URL
- App Store-specific availability notes
- source conflicts or rollout mismatches

## 4. Inspect the Source Data

If something looks suspicious, use **View Source JSON** or the source viewer options.

This is especially useful for:

- App Store lookup mismatches
- stale CDN responses
- Sparkle feed problems
- unknown or conflicting source results

## 5. Update Apps and Re-check

After updating one or more apps, MacOutdated tracks version changes and updates its live status.

Use the **Diagnostic Report** when you want a cleaner grouped snapshot of the current state for review or support.

# App Store Notes

Mac App Store apps can be tricky.

Sometimes Apple shows different data in different places:

- the App Store page
- the lookup API
- the updates UI on your Mac
- the appstoreagent logs

That means an app may appear to have:

- a staged rollout
- a delayed CDN update
- a withheld update for this Mac
- a lookup API conflict with the storefront page

MacOutdated tries to surface those situations rather than hiding them.

# When Something Looks Wrong

If an app result seems incorrect:

- Run diagnostic report, export in RTF format
- View App Details (click on application name) for the app in question, copy information using "Copy Details" button.
- Run source JSON viewer and copy results

Take the two and email me the results.

The goal is not just to say *outdated* or *up to date* — it is to make the update decision explainable.

# Permissions and Expectations

MacOutdated requires **Full Disk Access**, because it needs to inspect installed app bundles in locations that macOS may otherwise restrict.

Also note:

- some apps use unusual bundle layouts
- some apps are withheld by the Mac App Store process for various reasons. Staged rollouts where the app is only available to a small percentage of the userbase at start, for example. Maybe the update has issues and is paused. We detect this by looking at your mac system logs for notification of this from Apple.
- some update sources are inconsistent. In particular, if we are using Brew cask, it is not unusual to see a newer version availbe via Brew but not available via the app update method your installed app users. Confusing, yes.
- some apps intentionally do not expose a clear machine-readable latest version

MacOutdated tries to be transparent about those limits.
