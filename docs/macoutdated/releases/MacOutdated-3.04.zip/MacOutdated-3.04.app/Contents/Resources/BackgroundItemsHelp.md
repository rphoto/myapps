# Background Items Help

## What this page does

Background Items inventories the components on your Mac that run automatically without you explicitly launching them. This includes startup helpers, browser extensions, privileged tools, and bundled background services.

It currently scans:

- Bundled login item helpers inside installed apps
- User and system-level launch agents
- System launch daemons
- Legacy startup items
- Safari extensions
- Chromium-family browser extensions (Chrome, Edge, Brave, Arc)
- Firefox extensions
- Privileged helper tools
- ServiceManagement-submitted daemons (runtime launchd registrations)
- Bundled launch agents and launch daemons inside app bundles

## Why these checks matter

### Bundled login item helpers

These are small helper apps embedded inside a main application's bundle. macOS uses them to run background tasks automatically when you log in.

Why this matters:

- Most bundled helpers are legitimate and installed intentionally as part of a product you chose
- An unexpected helper can persist and run background code even if the main app is not open
- Reviewing these helps you identify software that is running at startup without a visible window

### Launch agents and daemons

Launch agents run in a user session context. Launch daemons run at the system level and are active regardless of who is logged in.

Why this matters:

- These are the main way macOS software registers background work
- Legitimate uses include software updaters, sync services, and system helpers
- They are also a common persistence mechanism for malware and unwanted software
- Unexpected items, especially daemons you do not recognize, deserve scrutiny

### Legacy startup items

`/Library/StartupItems` is a very old startup mechanism from earlier macOS versions. It is deprecated and rarely used by modern software.

Why this matters:

- Modern software should use launchd instead
- Anything present here on a current Mac is unusual and worth investigating

### Browser extensions

Extensions modify browser behavior and can read or alter the content of web pages you visit.

Why this matters:

- Extensions run with the privileges of the browser and can access any web content you view
- A malicious or compromised extension can read passwords, financial data, and private communications
- Extensions you installed long ago may have changed hands or updated to include unwanted behavior

### Privileged helper tools

Some apps install privileged helpers using legacy `SMJobBless`, typically placing binaries in `/Library/PrivilegedHelperTools`.

Why this matters:

- These tools run with full administrative access
- An orphaned helper without its parent app can represent incomplete removal or a leftover root-level background process
- A poorly written or malicious privileged helper can be a significant security risk

### ServiceManagement-submitted daemons (modern)

Modern macOS apps can register privileged daemons through ServiceManagement (`SMAppService`). These can appear in launchd as submitted/runtime-managed jobs instead of classic `/Library/LaunchDaemons` files.

Why this matters:

- This is a legitimate modern mechanism and may not create legacy on-disk artifacts in the locations older tools expect
- Runtime-managed jobs still represent persistent background capability and should be reviewed
- Parent bundle identifier, program identifier, and signer trust are key fields when validating legitimacy

### Bundled launch agents and daemons

Some apps embed launch agents or daemons inside their own app bundle under `Contents/Library/LaunchAgents` or `Contents/Library/LaunchDaemons`.

Why this matters:

- These run automatically alongside the parent app or on a schedule
- They are generally legitimate but can include update checks, telemetry, or sync services that run even when you are not using the app

## How to read the results

Each item shows the component name, its location on disk, the date it was installed or last modified, and its code-signing status.

The trust level indicator uses these levels:

- Concern (red): a code-signing problem such as an invalid signature, ad-hoc signing, or a broken certificate
- Advisory (orange): a notable finding that may be legitimate but deserves verification, such as a missing notarization or an expired certificate
- Informational (blue): present for visibility, not necessarily a problem
- Trusted (green): valid code signature from a recognized developer

Items marked as older than two years are highlighted to draw your attention. Outdated helpers from products you no longer use are good candidates for cleanup.

## Grouping

Use the grouping control in the toolbar to switch between:

- By Application: groups items under their parent application, when one can be identified
- By Category: groups items by type (launch agents, browser extensions, etc.)

## Filtering

- Search: type in the search field to filter by name, path, bundle ID, or trust information
- Show Problematic Only: toggle the filter to see only items with code-signing issues, missing targets, or age concerns

## Actions you can take

- Refresh: reload the full inventory
- Export: save a formatted RTF report
- Copy: copy a plain-text summary to the clipboard
- Context menu: right-click any item to copy its path, reveal it in Finder, or view its plist when available
- Move to Trash: remove an item you do not recognize or no longer need (use with care — some helpers are required for the parent app to work correctly)

## What not to assume

Many findings are expected. Most software you have installed will have at least one background component here.

Common legitimate examples:

- Backup apps with launch daemons for scheduled backups
- VPN clients with privileged helpers
- Developer tools with user launch agents
- Apps with bundled update-check helpers

Review the signer, vendor, install date, and whether you recognize the parent application before deciding to remove anything.

## Related help

- Use Security Scan to check for persistence mechanisms that are more clearly associated with malware, such as DYLD injection, cron jobs, emond rules, and SSH authorized keys
- Use the Security Explainer window for code-signing and Gatekeeper concepts
