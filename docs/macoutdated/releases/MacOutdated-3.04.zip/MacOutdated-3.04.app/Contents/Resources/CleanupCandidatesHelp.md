# Cleanup Candidates Help

This page explains what the **Cleanup Candidates** tool does, what it currently suggests, and why MacOutdated is still conservative about removal.

# What This Tool Is For

Cleanup Candidates is not a full uninstaller.

It is a review tool for files that often get left behind when someone removes an app by dragging `SomeApp.app` to the Trash and does not remove the app's support files, caches, preferences, or scripts.

MacOutdated currently looks for conservative cleanup candidates in your user Library, including:

- **empty user launch agent plists**
- **malformed user launch agent plists**
- **orphaned Application Support items**
- **orphaned Caches items**
- **orphaned Preferences plists**
- **orphaned Containers folders**
- **orphaned Application Scripts folders**

These are scanned in:

- `~/Library/LaunchAgents`
- `~/Library/Application Support`
- `~/Library/Caches`
- `~/Library/Preferences`
- `~/Library/Containers`
- `~/Library/Application Scripts`

# How Orphaned Items Are Detected

For the non-LaunchAgents categories, MacOutdated looks for items whose names look like third-party bundle identifiers and no longer match any currently installed app bundle identifier found in:

- `/Applications`
- `~/Applications`

Examples:

- `com.vendor.SomeApp` in `~/Library/Caches`
- `org.example.Tool.plist` in `~/Library/Preferences`
- `com.company.Product` in `~/Library/Containers`

This means the tool is aimed at obvious app residue, not arbitrary files in those folders.

# Why The Scope Is Still Conservative

MacOutdated should not guess aggressively about deletion.

Many files that look stale still belong to working software, helper tools, browsers, enterprise agents, or installers. The goal here is to surface obvious residue with a small blast radius, not to pretend that every old-looking file is safe to remove.

# What “Safe To Remove” Means Here

MacOutdated only suggests user-level files when the evidence is reasonably strong and the removal path is reversible.

For the current cleanup feature, that means:

- the item is in your user Library
- the item looks like app-specific residue rather than a generic shared file
- the item does not match any currently installed app bundle identifier
- removal sends the item to **Trash**, not permanent deletion

MacOutdated does **not** directly delete files.

# Why These Files Usually Exist

Common causes include:

- dragging an app bundle to the Trash without removing its Library files
- incomplete uninstallers
- failed updater migrations
- abandoned auto-update frameworks
- installers that wrote a launch agent and later stopped using it
- leftovers from apps that are no longer installed

# What The Page Shows

Each cleanup item shows:

- the item name
- the cleanup kind
- the reason it was suggested
- the most recent **modified date**
- an age marker when the file falls into one of these buckets:
  `Recent` for items {{cleanup_age_recent_description}},
  `Aged` for items {{cleanup_age_aged_description}},
  `Stale` for items {{cleanup_age_stale_description}}
- the full path

The modified date is intentionally used instead of creation date because it is usually the better signal for whether the item has been touched recently.

# Selection and Bulk Review

The page is designed as a review queue.

Current selection tools include:

- **View** at the top with `Safest to Delete` and `All Candidates`
- **Select Group** inside each section
- **Filter** chips at the top for `Recent`, `Aged`, and `Stale` when you are in `All Candidates`
- a tracker-focused filter chip to quickly focus on likely tracking residue
- **Deselect All**
- **Delete Selected**
- **Expand All** and **Collapse All**

This lets you work section by section instead of blindly selecting everything.

`Safest to Delete` is the default view. It narrows the list to:

- the lowest-risk cleanup candidates with the strongest ownership evidence

That view still applies conservative inclusion rules while keeping filter controls available so you can narrow what is visible before selecting.

When `Safest to Delete` is active, the page also shows reason chips such as:

- `Empty launch agent`
- `Malformed launch agent`
- `App confirmed deleted`
- `Empty folder`
- `Stale cache`
- `Tracker preference`

Those chips filter the already-safe list by why an item qualified.

Hover over a filter chip in `All Candidates` to see the current bucket definition. Those descriptions are generated from the same bucket settings the filter uses, so the help stays in sync if the thresholds change.

# What The Actions Do

## Display Item

Shows the plist contents in the source viewer when the cleanup candidate is a plist-backed item.

## Reveal

Shows the item in Finder.

## Move To Trash

Moves the item to the macOS Trash using the normal system trash flow.

## Restore

Restores an item from the most recent trash batch back to its original path, if that path is still free.

# Right-Click Support

Cleanup items support a context menu with actions such as:

- **Display Item**
- **Copy Path**
- **Google Search**
- **Reveal in Finder**
- **Move to Trash**
- **Restore**

Text on the page is also selectable, so you can copy item names and paths for review.

# How To Decide Whether To Remove Something

It is usually reasonable to remove a candidate shown on this page when:

- the item belongs to an app you no longer have installed
- the item name is clearly vendor-specific residue
- the item is very old
- the plist is empty or malformed
- you do not recognize the item and do not rely on software from that vendor

It is worth pausing before removal when:

- the related vendor app is still installed and actively used
- the file was modified recently
- you are using managed enterprise software
- you are debugging an installer, updater, or deployment issue
- the item may be shared by multiple products from the same vendor

# What This Tool Does Not Remove

MacOutdated still does **not** try to auto-suggest deletion for many riskier categories, including:

- system-wide items in `/Library`
- privileged helper tools
- system launch daemons
- helpers bundled inside app bundles
- browser-managed extension artifacts
- arbitrary files that do not clearly map to an app-style identifier

Those need stricter ownership checks and a more cautious policy before deletion should be suggested.

# Best Practice

Use Cleanup Candidates as a review queue:

1. Read the reason
2. Look at the modified date and age marker
3. Use **Display Item** or **Reveal** when you want more context
4. Start with **Safest to Delete** if you want the lowest-risk batch, or switch to **All Candidates** for a broader review
5. Use **Select Group** and the **Filter** chips in `All Candidates` to build a cautious batch
6. Move items to Trash, not permanent deletion
7. Reboot and verify your system before emptying Trash

The goal is to clean obvious residue without turning MacOutdated into an unsafe uninstaller.
