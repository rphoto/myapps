# What MacOutdated Does

MacOutdated scans the software installed on your Mac and compares each app or package to the newest version it can verify from a practical update source.

It is built around real-world Mac software, including:

- **Mac App Store apps**
- **Sparkle-based apps**
- **apps with known API endpoints**
- **apps whose latest version has to be read from a web page**
- **apps that fall back to the Homebrew cask catalog**
- **installed Homebrew packages**

# Main Areas of the App

MacOutdated currently includes these main sections:

- **Apps**
- **Homebrew**
- **Background Items**
- **Cleanup Candidates**
- **Security Scan**
- **Mac Compare** (shown only when more than one Mac is present in your synced CloudKit data)
- **Activity Log**
- **Backup**

The goal is not just to say *outdated* or *up to date*. The goal is to make the update path and the evidence behind it understandable.

# How the App Scan Works

MacOutdated scans common application folders, reads app bundle metadata, and then tries to determine:

- the app name
- the installed version
- the bundle identifier
- the update source
- the latest available version
- App Store-specific release and availability notes when relevant

It then groups app results into the sections you see on the main page:

- **App Store Outdated**
- **No Longer in App Store**
- **Non App Store Outdated**
- **Unknown Latest Version**
- **Up to Date**
- **Skipped - No Version Found**

## App Store update behavior

Mac App Store apps can be awkward because Apple may show different answers in different places:

- the App Store page
- the lookup API
- the updates UI on your Mac
- the `AppStoreAgent` system logs

MacOutdated tries to surface those situations instead of hiding them.

# Normal Workflow

## 1. Run a Scan

The **Apps** page scans installed apps and groups the results. You can watch progress while it works.

During the scan MacOutdated will:

- inspect installed app bundles
- check known update sources
- compare installed and latest versions
- inspect App Store-specific release and withholding clues for MAS apps
- group the results for review

## 2. Review the Results

Start with the outdated sections.

- **Mac App Store apps** may show `Open App Store Updates` or `Open App in App Store`, depending on whether Apple appears to be withholding or still rolling out the update
- **Sparkle apps** can show an `Update` button that triggers the app's embedded Sparkle updater
- **Other direct apps** usually show `Open`, which means you should use the app's own update mechanism
- **Unknown Latest Version** means MacOutdated could not determine a trusted latest version from the available metadata
- **No Longer in App Store** means the app still looks like an MAS install, but its current bundle ID no longer resolves to a current App Store listing

When MacOutdated later detects that a version actually changed, it marks the result as **Updated** with a green checkmark.

## 3. Click the App Name for Details

The **App Details** view is the first place to check when an app result looks surprising.

Use it to inspect:

- installed version
- latest version
- release date
- source URL
- App Store-specific availability notes
- source conflicts or rollout mismatches
- comparison versions used by MacOutdated

## 4. Inspect the Source Data

If something looks suspicious, use the source viewer from the app details view.

This is useful for:

- App Store lookup mismatches
- stale CDN responses
- Sparkle feed problems
- conflicting source results
- defaults exports and raw source content

## 5. Update and Re-check

After you update one or more apps, MacOutdated tracks version changes and refreshes the UI when it can confirm what actually changed.

When an app or package operation changes local software state (for example app updates detected by the app monitor, Homebrew package updates, or Homebrew deletes), MacOutdated now refreshes the app inventory, updates local cache data, and syncs app inventory state to iCloud so App Details, grouping, and Mac Compare stay aligned.

You can also **Copy** or **Export** the main page report for support or review work.

# Homebrew Page

The **Homebrew** page is separate from the app scan.

It loads your Homebrew inventory and supports:

- checking outdated Homebrew formulae and casks
- updating selected outdated packages
- deleting selected installed packages
- viewing installed package metadata
- Homebrew security findings for installed packages with known high or critical CVEs
- export and copy of Homebrew command output

# Background Items Page

The **Background Items** page inventories startup and helper components that can run outside a visible app window.

It includes things like:

- Launch Agents
- Launch Daemons
- Login Items
- Privileged Helper Tools
- browser-managed extensions and similar helper components

Useful features on this page include:

- grouping by **Application** or **Category**
- filtering to problematic items
- search
- copy and export
- trust and security summaries

When grouped by application, MacOutdated tries to associate background items with installed apps where possible. Items that cannot be tied to a current app are split into fallback groupings so uninstall residue is easier to spot.

# Cleanup Candidates Page

The **Cleanup Candidates** page is a conservative residue finder for user Library files left behind after app removal.

It currently looks for:

- empty or malformed user LaunchAgents plists
- orphaned Application Support items
- orphaned Caches items
- orphaned Preferences plists
- orphaned Containers folders
- orphaned Application Scripts folders

Each row shows the reason, the most recent modified date, and an age marker when the item falls into one of these buckets: `Recent`, `Aged`, or `Stale`. Those age bucket descriptions are injected from the same thresholds the cleanup UI uses.

Useful features include:

- a **View** switch between **Safest to Delete** and **All Candidates**
- **Select Group**
- **Filter** chips in **All Candidates** (including age buckets and tracker-focused filtering)
- **Expand All** and **Collapse All**
- **Delete Selected**
- per-item actions like **Copy Path**, **Google Search**, **Reveal in Finder**, **Move to Trash**, and **Restore**

Cleanup Candidates uses **Trash**, not permanent deletion. Treat it as a review queue, not as a full uninstaller.

# Security Scan Page

The **Security Scan** page checks for local macOS persistence mechanisms, insecure settings, and software vulnerability signals.

It includes checks such as:

- SIP, Gatekeeper, FileVault, and Application Firewall
- risky launchd environment-variable injection
- login/logout hooks
- cron jobs and periodic scripts
- emond rules
- SSH authorized keys
- TCC permission grants
- system extensions
- configuration profiles and MDM enrollment
- insecure Sparkle feeds
- Homebrew package vulnerability findings

Use the separate **Security Explainer** window for plain-language explanations of what those findings usually mean.

# Activity Log

The **Activity Log** records actions MacOutdated can observe, including things like:

- app upgrades it detects
- Homebrew package updates and deletes
- backup snapshot saves
- selected maintenance actions elsewhere in the app

Use the toolbar on the Activity Log page to:

- **Copy** — copy the visible log text for the selected Mac to the clipboard
- **Export…** — save the same content to a file
- **Reload from iCloud** — refresh entries from your synced Activity Log zone

On supported systems, MacOutdated can also prepare summaries for Apple Intelligence workflows when that feature is enabled.

For bulk maintenance (filtering, deleting entries, JSON import/export), open **Log Maintenance** from the utility tools. Expand **Advanced** there to import or export selected entries as JSON. Treat JSON import/export as an advanced operation; deletions are permanent.

# Backup Page

The **Backup** page stores Homebrew and `pyenv` state snapshots in iCloud so you can review, compare, and restore environment information later.

It supports:

- automatic startup and scheduled backup checks when Homebrew is installed
- manual backup
- snapshot history for this Mac
- latest snapshot view across multiple Macs
- compare views between snapshots
- generation of restore scripts and exportable restore content

# When Something Looks Wrong

If an app result seems incorrect:

- use **Copy** or **Export** from the main page
- open **App Details** and use **Copy** or **Export**
- open the source viewer and copy the raw data

That gives you a much better record of what MacOutdated actually saw.

# Mac Compare

The **Mac Compare** page appears only when MacOutdated detects more than one Mac in your synced CloudKit dataset. This keeps the main navigation simpler for single-Mac users.

Mac Compare uses synced zone datasets and local cache documents, then reloads from those sources as sync operations complete.

# Refresh, Cache, and iCloud Sync Timing

MacOutdated uses several different refresh paths. Some are manual, some happen when a page is opened, and some run on a schedule while the app is open.

## App and package update checks

- The **Apps** page performs a full app scan when the page first loads if no scan results are already available. You can also refresh it manually.
- After MacOutdated detects that an app changed version, it refreshes the local app inventory, updates the local app cache, and syncs app inventory state to iCloud.
- Homebrew package inventory is refreshed from the **Homebrew** page or after Homebrew update/delete operations. After local Homebrew changes, MacOutdated also saves a fresh Homebrew/`pyenv` snapshot for iCloud-backed backup and compare data.
- MacOutdated's own Sparkle updater is configured to check for MacOutdated updates every **6 hours**.

## iCloud and Mac Compare sync

- App inventory syncs to iCloud after an app scan and after local app inventory changes are confirmed.
- Activity Log changes schedule an iCloud sync immediately. If another log sync is already running, MacOutdated queues another pass.
- Mac Compare runs a background sync across its zones every **4 hours** while the app is open. It also does an initial sync on launch.
- Local compare data changes trigger a background Mac Compare sync, with a short **30-second** throttle so repeated changes do not start overlapping syncs.
- System information snapshots sync on launch and when the app becomes active, but no more often than every **4 hours** unless forced.
- The Mac Compare **Refresh All** command refreshes source data directly. If source data was refreshed less than **10 minutes** ago, it reloads current iCloud data instead of rerunning every source scan.

## Backup timing

- When Homebrew is installed, MacOutdated checks for a Homebrew/`pyenv` backup snapshot at startup.
- While the app remains open, it performs scheduled automatic backup checks every **4 hours**.
- A backup snapshot is saved only when the generated Homebrew/`pyenv` restore document has changed.
- If an automatic backup cannot run because the network is unavailable, MacOutdated waits for connectivity and retries.

## Security and historical caches

- The historical app registry refreshes at most once every **24 hours** unless forced. Its LaunchServices history scan also uses a **24-hour** refresh interval.
- TCC permission scan results can reuse a local cache for up to **24 hours** when protected TCC databases are temporarily inaccessible.
- Homebrew CVE lookup results from the OSV path are cached for **24 hours** per package/version.
- Security Scan results sync to iCloud after a scan completes. Background Items also sync their inventory to iCloud after a scan completes.

# Evidence Sources MacOutdated Uses

MacOutdated does not rely on a single update signal.

Instead, it combines several kinds of evidence depending on the app:

- App Store lookup results for bundle ID matching, version metadata, and release dates
- `AppStoreAgent` system logs to detect clues that Apple is withholding, delaying, or not yet offering a Mac App Store update to this Mac
- Sparkle app metadata and feed URLs for Sparkle-based apps
- direct API endpoints, release feeds, or vendor web pages for non-App-Store apps that publish version information outside Sparkle
- the Homebrew formula and cask catalog for apps and packages that map better to Homebrew than to the vendor's own updater

These sources do not always agree with each other.

For example, Apple may publish a newer Mac App Store version in the lookup API before the update is actually offered to your Mac. That is one reason MacOutdated pays attention to `AppStoreAgent` evidence instead of assuming the lookup result alone means the update is immediately installable.

MacOutdated tries to show those mismatches rather than flattening them into a single misleading answer.

# Permissions and Expectations

MacOutdated requires **Full Disk Access** because it needs to inspect installed app bundles and other locations that macOS may otherwise restrict.

Also note:

- some apps use unusual bundle layouts
- some App Store apps are withheld, staged, or region-limited
- some update sources are inconsistent
- some apps intentionally do not expose a clean machine-readable latest version
- Homebrew catalog versions and app self-updaters may disagree

MacOutdated tries to be explicit about those limits rather than pretending every source is clean or consistent.
