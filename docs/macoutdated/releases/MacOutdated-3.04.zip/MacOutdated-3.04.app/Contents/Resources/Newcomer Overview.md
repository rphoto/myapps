# Newcomer Overview

## What this project is

**MacOutdated** is a SwiftUI macOS app for auditing software health on macOS:
- discover installed apps and detect outdated versions,
- inspect Homebrew package drift,
- review background items and security findings,
- compare inventory snapshots across Macs using CloudKit.

The design goal is to keep scanning/parsing work in services/view models while views stay mostly declarative.

---

## Repository map (high level)

- `MacOutdated/` — main application target (SwiftUI views, view models, stores, services).
- `MacOutdatedTests/` — unit tests for parsing, state transitions, and data transforms.
- `MacOutdatedUITests/` — fixture-driven UI tests.
- `CloudKit/` — CloudKit schema artifacts and `README.md` for schema push/pull.
- `Sparkle-2.9.3/` — vendored Sparkle framework consumed by the app.
- `Scripts/` — developer scripts (CloudKit schema helpers, diagnostics).
- `ci_scripts/` — Xcode Cloud post-clone hook (`ci_post_clone.sh`).
- `docs/` — maintainer docs (for example `XcodeCloud.md`).
- `MacOutdated.xctestplan` — full local test plan (unit + UI tests).
- `MacOutdatedUnit.xctestplan` — unit-test-only plan for Xcode Cloud CI.
- `MacOutdated.xcodeproj/xcshareddata/xcschemes/` — shared Xcode schemes (required for Xcode Cloud).

---

## Runtime structure

### 1) App startup and global wiring
`MacOutdated/MacOutdatedApp.swift` is the `@main` entry point.

It:
- creates long-lived feature view models (`ScannerViewModel`, `SecurityScanViewModel`, `BackupViewModel`, etc.),
- initializes shared stores (`ActivityLogStore`, `AppInfoStore`, `XcodeAIAgentVersionStore`),
- registers auxiliary windows (help/docs/inspectors/maintenance tools),
- configures Sparkle updater integration and app command menus,

### 2) Main shell and navigation
`MacOutdated/ContentView.swift` is the app shell with `NavigationSplitView`.

It:
- routes to destination pages (Apps, Homebrew, Background Items, Cleanup Candidates, Security Scan, Mac Compare, Activity Log, Backup),
- gates main UI behind Full Disk Access,
- hides Homebrew-only sections when Homebrew is unavailable,
- hides **Mac Compare** unless CloudKit data shows multiple Macs (`hasMultipleMacsInCloud`),
- runs startup/background tasks (backup cadence, sync checks, onboarding help triggers).

### 3) Navigation model
`MacOutdated/AppNavigation.swift` provides:
- `AppDestination` enum (labels/icons/order semantics),
- shared `AppNavigationState` used by the shell and destination selection logic.

---

## Feature-first organization pattern

The codebase uses feature prefixes and companion files so related symbols group together in Xcode.

Example:
- `SecurityScanView.swift` (screen layout + interaction wiring)
- `SecurityScanViewModel.swift` (state machine, async actions, user intents)
- `SecurityScanScanner.swift` (scan implementation)
- `SecurityScanSectionViews.swift` (reusable subviews/rows/sections)

General rule of thumb:
- **View files**: composition, local UI state, and user affordances.
- **View model files**: observable state and async workflow orchestration.
- **Service/store/scanner files**: filesystem/process/network/CloudKit/parsing/persistence.

---

## Core data model: memory, cache, and cloud

### In-memory stores (runtime truth for UI)
- `ScannerViewModel` holds app scan sections, app actions, and Homebrew state.
- `SecurityScanViewModel`, `BackgroundItemsViewModel`, `BackupViewModel`, etc. hold feature-local runtime state.
- `MacCompareViewModel` composes cross-zone/cross-host datasets for compare views.
- `AppInfoStore` is the app-inventory sync store used for app-level CloudKit records.

### File caches (startup resilience + offline continuity)
The app uses file-backed caches so the UI can recover useful state quickly between launches:
- `AppInfoStore.recordsFileURL` (`appInfo.json`) + sync state file (`appInfo-sync.json`).
- `BrewSnapshotStore` cache file for snapshot list/content metadata.
- `MacCompareCloudStores` cache files per zone/record type for compare datasets.
- Additional feature stores (for example `XcodeAIAgentVersionStore`) also persist local JSON caches.

These caches are not a replacement for CloudKit; they are local continuity layers.

### CloudKit (cross-Mac/shared state)
CloudKit is used as shared durable storage across Macs and app sessions.

Current major synced domains include:
- App inventory (`AppInfoStore`)
- Activity log
- Brew snapshots
- Background items
- Security scan inventory
- Historical app registry data used by cleanup/security confidence logic
- System info + compare-support datasets used by Mac Compare

Pattern used across most domains:
1. Load local cache into memory at startup.
2. Refresh/sync with CloudKit (foreground on demand, background when appropriate).
3. Persist updated local cache.
4. Publish updated in-memory state to UI.

---

## Data-flow examples

### Apps scan flow
1. `ScannerViewModel.performScan()` runs local app scan and version-source checks through `AppScanner`.
2. Results are grouped into UI sections in memory.
3. `AppInfoStore.processScanResults(allScannedApps)` updates app inventory state.
4. `AppInfoStore` writes local cache and schedules/pushes CloudKit sync.

### Local mutation flow (important recent behavior)
When local operations change software state (app update detected, Homebrew package update/delete), `ScannerViewModel.refreshAppInventoryAfterMutation()` now runs:
1. Re-scan local apps and rebuild groups.
2. Update in-memory sections.
3. Call `AppInfoStore.processScanResults(...)`.
4. Force `await AppInfoStore.shared.syncWithCloudNow()`.
5. Emit `MacCompareOperationSyncSupport.notifyLocalDataDidChange()`.

This keeps app list category status, app details, cache files, and CloudKit app records aligned after local actions.

### Mac Compare refresh flow
- `MacCompareViewModel.refreshSyncStatusOnly()` does a status-only pass (lower-cost check).
- Full compare reload paths read from stores/caches and refresh from source/CloudKit as needed.
- `ContentView` uses `hasMultipleMacsInCloud` to decide whether Mac Compare should appear in navigation.

---

## Important systems to understand first

### App scanning and version-source resolution
- `MacOutdated/ScannerViewModel.swift` is central app state for app scan results, Homebrew package state, update actions, and test-mode switches.
- `MacOutdated/AppScanner.swift` defines app/source models and lower-level scanning/source diagnostics.

### Security scanning and remediation
- `MacOutdated/SecurityScanViewModel.swift` manages scan lifecycle, progress/finding aggregation, TCC-oriented cleanup actions, and inventory sync output.

### Backup and snapshot sync
- `MacOutdated/BackupViewModel.swift` handles Homebrew/pyenv snapshot creation, retry behavior for connectivity loss, and snapshot history loading.

### Cross-machine compare
- `MacOutdated/MacCompareViewModel.swift` loads datasets (apps/system info/brew/background/security/historical) and computes side-by-side diffs.

---

## First-day learning plan (recommended)

1. **Boot flow (30 min)**
   - Read `MacOutdatedApp.swift`, then `ContentView.swift`.
   - Understand window registration, destination routing, startup tasks.

2. **Scanning core (45 min)**
   - Read `ScannerViewModel.swift` and `AppScanner.swift`.
   - Trace how results become sections/status text/actions.

3. **One vertical feature (45 min)**
   - Security path: `SecurityScanView` → `SecurityScanViewModel` → `SecurityScanScanner`.
   - Backup path: `BackupView` → `BackupViewModel` → `BrewSnapshotStore`.

4. **Cross-machine data path (30 min)**
   - Read `MacCompareViewModel.swift` and related inventory/cloud stores.

5. **Test guardrails (30 min)**
   - Review `MacOutdatedTests` + `MacOutdatedUITests` before changing startup/background scans.

---

## Testing and automation conventions

### Test plans and schemes
- **Local full run:** scheme `MacOutdated` + test plan `MacOutdated.xctestplan` (unit + UI tests).
- **Xcode Cloud / CI:** scheme `MacOutdated` + test plan `MacOutdatedUnit` (unit tests only). See [docs/XcodeCloud.md](../docs/XcodeCloud.md).

```bash
xcodebuild test \
  -project MacOutdated.xcodeproj \
  -scheme MacOutdated \
  -testPlan MacOutdatedUnit \
  -destination 'platform=macOS'
```

### Unit tests
- `MacOutdatedTests/MacOutdatedTests.swift` — deterministic logic (decode/normalize/merge/state behaviors).

### UI tests
`MacOutdatedUITests/MacOutdatedUITests.swift` uses explicit launch fixtures and toggles, e.g.:
- `--ui-test-fixture-apps`
- `--ui-test-fixture-brew`
- `--ui-test-bypass-fda`
- `--ui-test-disable-help`
- `--ui-test-no-homebrew`

Run UI tests locally; keep them out of Xcode Cloud until flake/TCC issues are addressed.

### Critical convention
Prefer explicit runtime gating for test runs (`ScannerViewModel.isRunningAutomatedTests`) instead of introducing separate compile-time test-only production logic.


---

## Practical contributor tips

- Keep changes narrow and feature-local.
- Move complex non-UI logic out of view bodies into view models/services.
- Prefer async/await for new asynchronous work.
- Preserve existing naming/layout conventions so files stay grouped alphabetically in Xcode.
- When changing startup tasks, explicitly decide behavior under automated tests.
- If you touch sync/mutation paths, think in this order:
  1. in-memory state update,
  2. local cache persistence,
  3. CloudKit sync,
  4. UI notification/reload hooks.
