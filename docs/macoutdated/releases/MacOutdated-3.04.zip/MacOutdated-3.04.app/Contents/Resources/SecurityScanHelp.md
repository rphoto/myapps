# Security Scan Help

## What this page does

Security Scan looks for local macOS persistence mechanisms, insecure configurations, and software vulnerabilities that are often worth reviewing when a Mac is behaving strangely or has software you no longer recognize.

It currently checks:

- Core macOS security controls (SIP, Gatekeeper, FileVault, Application Firewall)
- sudoers policy and passwordless admin delegation
- Shell startup persistence in common login shell rc/profile files
- Environment-variable injection in launchd plists
- Launchd jobs with missing, unresolved, writable, or shadow-binary targets
- Login and logout hooks
- Cron jobs
- Non-Apple periodic scripts
- Emond persistence rules
- SSH authorized keys
- Privacy and permission grants (TCC)
- System extensions
- Configuration profiles and MDM enrollment
- Insecure Sparkle update feeds
- Known CVEs in outdated Homebrew packages (via osv.dev)

## Why these checks matter

### System Security Posture

MacOutdated checks four core macOS security controls: System Integrity Protection, Gatekeeper, FileVault, and the Application Firewall.

Why this matters:

- SIP prevents modification of protected system files and directories even by root. Disabling it leaves the system open to rootkit-style attacks
- Gatekeeper blocks unsigned and unnotarized software. Disabling it lets malicious software run without any macOS checks
- FileVault encrypts your disk. Without it, anyone with physical access can read all your data by booting from another volume
- The Application Firewall blocks unsolicited incoming network connections to apps and services

What an attacker may gain:

- With SIP off: the ability to modify protected system binaries, install kernel extensions, or persist in ways that normally require Apple's permission
- With Gatekeeper off: silent installation and execution of unsigned or malicious software
- With FileVault off: immediate full-disk access to a stolen or unattended machine
- With the firewall off: easier inbound connection attempts to listening services

### sudoers policy and passwordless admin delegation

MacOutdated checks `/etc/sudoers` and `/etc/sudoers.d` for rules that allow broad elevation or let commands run without a password.

Why this matters:

- `NOPASSWD` rules can remove a key checkpoint before privileged commands run
- Broad `ALL=(ALL)` style grants may be legitimate for administrators, but they are also a common persistence or lateral-movement foothold
- Writable or incorrectly owned sudoers fragments are especially risky because they can let another user or process change admin policy silently

What an attacker may gain:

- Password-free privilege escalation for selected or all commands
- A durable way to preserve administrative access even after app-level cleanup

### Shell startup persistence

MacOutdated checks common login shell startup files such as `~/.zshrc`, `~/.zprofile`, `~/.bash_profile`, and system-wide shell profile files for suspicious persistence patterns.

Why this matters:

- Shell startup files run automatically when a user opens a shell or logs in through workflows that invoke the user's shell environment
- Attackers and sloppy installers both use these files to relaunch commands, bootstrap payloads, or re-register launch agents
- Remote bootstrap pipes such as `curl ... | sh` and DYLD exports are especially worth reviewing

What an attacker may gain:

- Automatic user-level code execution on shell startup
- Repeated reinstall or beacon logic hidden in a place many users never inspect
- A way to manipulate environment variables before trusted tools run

### Environment-variable injection in launchd plists

MacOutdated looks for launchd jobs that set dangerous `DYLD_*` environment variables such as `DYLD_INSERT_LIBRARIES`.

Why this matters:

- These variables can force another process to load attacker-controlled code before the app fully starts
- They can be used as a stealthy persistence method because the malicious code runs inside an otherwise normal process
- They can let an attacker tamper with app behavior, capture data, bypass trust decisions inside the app, or piggyback on the permissions of the process being launched

What an attacker may gain:

- Code execution inside apps or background services
- A way to relaunch malicious code automatically every time a launchd job starts
- Access to whatever files, network access, or entitlements that target process already has

### Launch target hygiene

MacOutdated also resolves launchd targets and flags jobs whose executable target is missing, not clearly resolvable, unexpectedly writable, or running from a risky location such as `Application Support`.

Why this matters:

- A missing target often means a broken leftover that still tries to persist
- A writable launch target is more serious because another process or user may be able to replace what launchd executes
- Persistent binaries running outside a normal app bundle can be legitimate, but they deserve closer scrutiny

What an attacker may gain:

- A stealthy persistence point that survives reboots and user logins
- A way to swap in a different executable behind an already-registered launchd job

### Login and logout hooks

MacOutdated checks old `com.apple.loginwindow.plist` settings for `LoginHook` and `LogoutHook`.

Why this matters:

- Login hooks are an old persistence mechanism that runs scripts automatically when a user signs in or out
- Legitimate use is now rare, so unexpected entries deserve attention
- A hidden login hook can survive for a long time because most users never inspect these preference files

What an attacker may gain:

- Automatic execution at every login
- A simple place to relaunch malware, reinstall deleted components, or trigger follow-on payloads
- A way to start surveillance, credential theft, or command-and-control activity as soon as a user session begins

### Cron jobs

MacOutdated checks user crontab files in `/var/at/tabs`.

Why this matters:

- `cron` is older than modern macOS launchd tooling, but it still works
- Unexpected cron entries can be a persistence mechanism, especially on Macs used by developers or administrators
- Cron often runs quietly, so a malicious scheduled job may not be noticed unless someone inspects it directly

What an attacker may gain:

- Repeated scheduled execution
- A way to download payloads again after removal
- A mechanism to run scripts on a timer for exfiltration, beaconing, cleanup, or lateral movement tasks

### Non-Apple periodic scripts

MacOutdated checks `/etc/periodic/daily`, `/etc/periodic/weekly`, and `/etc/periodic/monthly` for non-Apple scripts.

Why this matters:

- These directories are meant for scheduled maintenance
- Apple's built-in scripts are predictable, so extra custom scripts stand out
- Attackers or unwanted admin tooling can abuse these locations to regain execution without adding more obvious login items

What an attacker may gain:

- Low-frequency persistence that may avoid notice
- The ability to rerun cleanup-resistant tasks, download tools, or reopen access after a reboot
- A way to blend into a maintenance-style workflow instead of a visible app launch path

### Emond persistence rules

MacOutdated checks `/etc/emond.d/rules/` for rule files that could trigger script or command execution in response to system events.

Why this matters:

- Emond (Event Monitor Daemon) is a deprecated macOS feature removed in macOS 13 Ventura, but the file paths still exist on older or upgraded systems
- Malware has used emond rules as a persistence mechanism because they are rarely inspected
- Any rule file in this location on a modern Mac is unusual and deserves scrutiny

What an attacker may gain:

- Automatic execution in response to system events such as system startup
- A persistence mechanism that survives user-level cleanup because it sits in a protected directory

### SSH authorized keys

MacOutdated checks `~/.ssh/authorized_keys` and `/var/root/.ssh/authorized_keys` for entries that grant password-free SSH login to this Mac.

Why this matters:

- Each entry in these files allows the holder of the matching private key to SSH into this Mac without a password
- Root-level keys are especially dangerous because they give an attacker full administrative access
- A compromised Mac could have keys added silently by malware or an attacker who previously had access

What an attacker may gain:

- Persistent, password-free remote access that survives reboots, account password changes, and many malware removal attempts
- Root-level keys provide complete control of the system

### Privacy and permission grants (TCC)

MacOutdated reads the macOS Transparency, Consent, and Control (TCC) databases to show which apps have been granted sensitive system permissions.

Why this matters:

- Apps with Full Disk Access, Screen Recording, Input Monitoring, or Accessibility permissions have very broad system reach
- These permissions are granted deliberately but can be abused by malicious software that acquires them through deception or inherited approval
- Reviewing this list helps you spot apps that have more access than you expect or recognize

What an attacker may gain by abusing high-privilege grants:

- Full Disk Access: the ability to read all files, including credentials, keys, and documents
- Screen Recording: the ability to capture everything visible on your screen
- Input Monitoring: the ability to log keystrokes and observe all keyboard input
- Accessibility: the ability to control other apps, simulate input, and read UI content from any application

### System extensions

System extensions are privileged components used for networking, endpoint security, device drivers, VPNs, and related system-level features.

Why this matters:

- They operate with more trust and deeper system access than a normal user app
- A legitimate vendor may install them, but an unexpected or poorly signed extension deserves scrutiny
- Even when the extension itself is valid, an orphaned extension without its host app can mean incomplete removal or suspicious leftovers

What an attacker may gain:

- Deep visibility into network traffic or endpoint activity
- The ability to filter, redirect, inspect, or interfere with system traffic depending on the extension type
- A durable foothold that continues to run outside the main app UI

MacOutdated shows:

- The extension identifier and version
- The host app, when one can be found
- Code-signing status
- Signer name and team ID
- Hardened runtime status

If code signing is valid, MacOutdated highlights that line with a green check so it is easier to distinguish trusted signing information from neutral metadata.

### Configuration profiles and MDM enrollment

MacOutdated checks for installed configuration profiles and whether the Mac appears to be enrolled in Mobile Device Management.

Why this matters:

- Profiles can enforce system settings, trust settings, network behavior, certificates, VPN configuration, web filtering, and management restrictions
- On a work Mac this is often expected, but on a personal Mac an unknown profile can be highly significant
- MDM enrollment can allow very broad centralized control over the machine

What an attacker or unwanted administrator may gain:

- The ability to install trusted certificates and intercept traffic in some scenarios
- The ability to force network proxies, VPNs, restrictions, managed login behavior, or security settings
- Ongoing remote policy control over the Mac

### Insecure Sparkle update feeds

MacOutdated checks apps that use the Sparkle framework for updates to confirm that their update feed URL uses HTTPS rather than plain HTTP.

Why this matters:

- HTTP update feeds are vulnerable to man-in-the-middle attacks where a network attacker silently replaces the legitimate update with a malicious one
- The Sparkle framework is widely used and apps that still use HTTP feeds expose their users to this attack even if the rest of the app is trustworthy

What an attacker may gain:

- The ability to push a tampered app update to any user on the same network — for example at a coffee shop, corporate network, or hotel Wi-Fi
- Code execution under the user's account with the app's full permissions

### Known CVEs in outdated Homebrew packages

When outdated Homebrew packages are loaded, MacOutdated queries the OSV.dev open vulnerability database to check for known CVEs affecting the installed versions.

Why this matters:

- Outdated packages may have publicly disclosed vulnerabilities with available exploits
- CVE information provides a concrete reason to prioritize specific updates
- The OSV.dev database aggregates data from GitHub Advisory Database and other sources, covering many common Homebrew packages

What an attacker may gain:

- Exploitation of a known, publicly documented vulnerability in software already on your Mac
- Depending on the package, this can range from local privilege escalation to remote code execution

## How to read the results

Each finding is grouped into a section and labeled with one of these levels:

- Concern: high-priority item that deserves investigation
- Advisory: notable item that may be legitimate, but should be verified
- Informational: present for visibility, but not necessarily a problem

The icon color matches that level:

- Red for concerns
- Orange for advisories
- Blue for informational items

## Actions you can take

- Refresh: run the scan again
- Copy: copy a report of the current findings
- Search: filter findings by text
- Context menu: right-click a row to copy its path, reveal it in Finder, or view its plist when available

## What not to assume

Many findings are legitimate. A finding does not automatically mean malware or tampering.

Examples:

- Configuration profiles are common on work-managed Macs
- System extensions are common for VPNs and security tools
- Cron jobs and periodic scripts can be installed by administrators or developer tools
- Privacy permission grants like Full Disk Access are normal for backup software, developer tools, and security products

Review the signer, vendor, install path, and whether you recognize the related app before deciding something is suspicious.

## Related help

- Use the Security Explainer window for code-signing and Gatekeeper concepts
- Use Background Items for launch agents, launch daemons, login items, and privileged helper tools
