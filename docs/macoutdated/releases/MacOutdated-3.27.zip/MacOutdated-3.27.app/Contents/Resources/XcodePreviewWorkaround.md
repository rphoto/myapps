# Xcode Preview Workaround

## Summary

Xcode Previews can fail for the `MacOutdated` app target with this error:

```text
Could not analyze the built target description for MacOutdated to create the preview.
CouldNotFindLibrary: Could not find library with name "/usr/lib/swift/libswiftWebKit.dylib"
```

This appears to be an Xcode beta / macOS SDK preview-analysis bug. The app builds normally, and `WebKit.framework` can be linked explicitly, but the preview analyzer still inspects `MacOutdated.debug.dylib` and fails on an obsolete absolute Swift overlay load command for `libswiftWebKit.dylib`.

Treat this as a temporary workaround until Apple fixes the preview analyzer or SDK stub behavior.

## Workaround

Add a Debug-only Run Script build phase to the `MacOutdated` app target after linking. The script rewrites the bad debug-dylib load command to the system WebKit framework and re-signs the debug dylib.

```bash
set -euo pipefail

if [[ "${CONFIGURATION}" != "Debug" || "${ENABLE_DEBUG_DYLIB:-}" != "YES" ]]; then
    exit 0
fi

debug_dylib="${TARGET_BUILD_DIR}/${CONTENTS_FOLDER_PATH}/MacOS/${PRODUCT_NAME}.debug.dylib"
missing="/usr/lib/swift/libswiftWebKit.dylib"
replacement="/System/Library/Frameworks/WebKit.framework/Versions/A/WebKit"

if [[ -f "$debug_dylib" ]] && /usr/bin/otool -L "$debug_dylib" | /usr/bin/grep -q "$missing"; then
    /usr/bin/xcrun install_name_tool -change "$missing" "$replacement" "$debug_dylib"

    if [[ "${CODE_SIGNING_ALLOWED:-}" != "NO" ]]; then
        if [[ -n "${EXPANDED_CODE_SIGN_IDENTITY:-}" && "${EXPANDED_CODE_SIGN_IDENTITY}" != "-" ]]; then
            /usr/bin/codesign --force --sign "$EXPANDED_CODE_SIGN_IDENTITY" --timestamp=none "$debug_dylib"
        else
            /usr/bin/codesign --force --sign - "$debug_dylib"
        fi
    fi
fi
```

## Notes

- Keep `ENABLE_DEBUG_DYLIB` enabled. Xcode 26 previews require it for executable targets.
- Explicitly linking `WebKit.framework` alone does not fix this failure.
- Adding SDK Swift overlay paths to `LIBRARY_SEARCH_PATHS` does not fix this failure.
- Remove this workaround after a future Xcode beta or release no longer emits or requires the bad `/usr/lib/swift/libswiftWebKit.dylib` load command.
