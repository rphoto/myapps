# MacOutdated Agent Notes

This project is a SwiftUI macOS app maintained in Xcode. Keep changes conservative, localized, and aligned with the existing feature-based file layout.

## macOS Target And Compatibility Policy

- macOS 15.0 is the minimum supported OS. Do not add macOS 14/Sonoma compatibility shims.
- Treat macOS Sequoia and Tahoe as the supported product direction.
- Prefer modern APIs available at the macOS 15 deployment target or newer.
- Keep newer-OS feature gates explicit when an API truly requires a later OS than the deployment target.

## Local Tool Paths

When running shell commands, include `/opt/homebrew/bin` as the preferred location for developer tools. If a Homebrew-installed tool is needed, use its absolute path under `/opt/homebrew/bin` rather than relying on shell PATH lookup.

## File Organization

- Use feature prefixes so related files group together alphabetically in Xcode.
  - Examples: `SecurityScanView.swift`, `SecurityScanViewModel.swift`, `SecurityScanScanner.swift`, `SecurityScanSectionViews.swift`.
  - Examples: `XcodeAIAgentModels.swift`, `XcodeAIAgentProbe.swift`, `XcodeAIAgentVersionStore.swift`.
- Keep primary view files focused on page composition and local UI state.
- Move substantial support code into companion files:
  - `...Models.swift` for shared data types.
  - `...ViewModel.swift` for observable state and user actions.
  - `...Scanner.swift`, `...Service.swift`, or `...Store.swift` for filesystem, process, network, persistence, and parsing work.
  - `...Sheets.swift`, `...SectionViews.swift`, or `...Row.swift` for reusable SwiftUI pieces.
- Prefer moving whole declarations over interleaving partial extensions unless there is a clear readability win.

## SwiftUI And Architecture

- Views should mostly describe UI. Avoid putting scanning, parsing, shell execution, network calls, or persistence directly in view bodies.
- Use `@State private var` for view-local state and `@Bindable`/observable view models for shared page state.
- Prefer Swift async/await APIs. Do not introduce Combine for new code.
- Keep access levels as narrow as practical. When splitting files, widen `private`/`fileprivate` only for declarations that genuinely need cross-file access.
- Reuse existing report, source-viewer, context-menu, and helper APIs instead of creating parallel patterns.
- For any new user-visible preference or disclosure state, decide and implement persistence explicitly: use a keyed setting (`@AppStorage`/`UserDefaults`) when it should survive relaunch, and include that key in `AppSettingsCloudSync.syncedKeys` when it should roam across Macs. Use plain `@State` only for intentionally ephemeral UI state.

## Refactoring Standards

- Avoid regex-heavy mass rewrites on large Swift files. Prefer small patches or simple line-range moves that preserve implementation text.
- After moving code across files, check for access-control fallout before making semantic changes.
- Do not mix mechanical file-splitting with behavior changes unless the user explicitly asks for both.
- Preserve existing names and public behavior during structural refactors.
- Keep new files added to the Xcode project, not just the filesystem.

## UI Consistency

- Use existing color semantics unless changing a feature deliberately:
  - Green: good/current/success.
  - Orange: warning/advisory/medium risk.
  - Red: concern/high risk/destructive or failed.
  - Blue/secondary: informational or neutral.
- Prefer existing SwiftUI controls, labels, button styles, and sheet layouts already used in nearby files.
- Watch for narrow-window behavior in list-heavy pages. UI tests may expose hit-testing or off-screen control problems.

## Xcode Cloud CI

- Shared scheme: `MacOutdated.xcodeproj/xcshareddata/xcschemes/MacOutdated.xcscheme` (may be gitignored locally; force-add when changed).
- **CI test plan:** `MacOutdatedUnit` (unit tests only). **Local full plan:** `MacOutdated.xctestplan` (unit + UI).
- Post-clone: `ci_scripts/ci_post_clone.sh` adds `/opt/homebrew/bin` to `PATH` when present.
- Maintainer setup: [docs/XcodeCloud.md](docs/XcodeCloud.md). Workflow should use **Test** with `MacOutdatedUnit`, not Archive-only.

```bash
xcodebuild test -project MacOutdated.xcodeproj -scheme MacOutdated \
  -testPlan MacOutdatedUnit -destination 'platform=macOS'
```

## Validation

- Prefer Xcode tools for Swift work:
  - Run live diagnostics on touched files with `XcodeRefreshCodeIssuesInFile`.
  - Run `BuildProject` after adding, moving, or renaming Swift files.
  - Run the full test plan after structural refactors or shared behavior changes.
- For UI test failures, distinguish app regressions from window-position or hit-testing flakes by rerunning the specific failing test.
- Report any tests not run or any known flaky result clearly.
### Subprocess Safety (Hang Prevention)

- Any new `Process` invocation used by scanners/background inventory must have a hard timeout. Do not allow unbounded waits.
- Do not rely on `waitUntilExit()` alone for commands that may produce large output; ensure stdout/stderr are drained safely.
- If a subprocess exceeds timeout, terminate it and fail open for non-critical inventory (skip that group rather than blocking the page).
- Keep expensive or potentially noisy runtime probes off critical UI load paths when possible.

## Test And Privacy Rules

- Keep automated tests deterministic and side-effect-light. Tests should not depend on the real machine state when fixtures or injected data can be used instead.
- Prefer runtime test gating over new compile-time test forks. This project currently uses `ScannerViewModel.isRunningAutomatedTests` plus UI-test launch arguments and environment values; do not introduce separate `TEST` or `UITEST` compile flags unless the user explicitly asks for that architecture change.
- `#if DEBUG` is acceptable for previews, debug helpers, and preview-only setup. Do not hide real production logic behind `#if DEBUG` just to make tests pass.
- When new startup work is added, decide explicitly whether it should run during automated tests. Background update checks, backups, network sync, telemetry-like logging, and machine-wide scans should usually be skipped during UI tests.
- UI tests should launch the app with explicit fixture/bypass arguments rather than depending on ambient state. Reuse the existing `--ui-test-...` pattern and centralize new flags in `ScannerViewModel` when possible.
- Unit tests should prefer dependency injection or pure helper functions over touching the real filesystem, real network, real CloudKit, or real user defaults. If a service must be exercised, add a narrow seam rather than mocking half the app.
- Avoid writing tests that require real Homebrew installs, real app bundles in protected locations, real TCC databases, or real browser/profile data. Use fixtures, temporary directories, or preloaded view-model state instead.

### Avoiding Privacy And TCC Prompts

- Never let automated tests trigger scans of protected user data unless the test is explicitly about that permission flow.
- In this project, common prompt sources include `~/Library/Containers`, `~/Library/Application Scripts`, TCC-related paths, browser profile folders, backup/sync tasks, and launch-time app scans that enumerate real installed software.
- If a view or view model reads protected paths, add a test-safe path that returns fixture data or no-op results when `ScannerViewModel.isRunningAutomatedTests` is true.
- `PublicInternetConnectivity` skips the captive-portal probe during `ScannerViewModel.isRunningAutomatedTests` and treats a satisfied path as reachable so unit/UI tests do not need live network access.
- If a UI test only needs rendering, do not start follow-on work such as security scans, updater checks, startup backups, CloudKit refreshes, or background inventory passes.
- If a permission prompt appears and the test still passes when denied, treat that work as unwanted for automated tests and gate it off.
- Prefer narrowly scoped guards at the task or service boundary. Do not broadly disable unrelated app features just because one test path needs isolation.

### Test Maintenance Expectations

- When adding a new feature, consider test strategy as part of the implementation:
  - What is the pure logic that should get unit coverage?
  - What UI state should get fixture-driven UI coverage?
  - What startup or background work must be gated off for automated runs?
- Keep test knobs discoverable. New launch arguments, environment keys, and fixture loaders should be named consistently and documented near `ScannerViewModel.isRunningAutomatedTests`.
- If a new test helper changes app launch behavior, preserve normal production behavior by default and make the test behavior opt-in.
- When fixing a flaky or privacy-sensitive test, prefer removing the hidden dependency rather than adding sleeps, retries, or prompt-clicking logic.

## Git And Workspace Safety

- The workspace may contain user changes. Do not revert unrelated edits.
- Check `git status --short` before and after broad work.
- Do not use destructive git commands unless explicitly requested.
- If Xcode asks whether to keep the Xcode version or the on-disk version, prefer the on-disk version when an agent has just edited files outside Xcode.
