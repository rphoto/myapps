# Claude Instructions

Before making changes, read and follow [AGENTS.md](./AGENTS.md).

`AGENTS.md` is the canonical source of repository coding-agent instructions for this project.
