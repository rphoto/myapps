# macOS 15+ Compatibility Notes

This is a developer-facing note. Do not surface it in the app help menu or user documentation.

MacOutdated now targets macOS 15.0 or newer. Sonoma support has been removed so the app can focus on Sequoia and Tahoe behavior without carrying macOS 14 compatibility shims.

## Deployment Target Context

The app and helper deployment targets should remain at macOS 15.0 or newer. Do not lower the deployment target to macOS 14/Sonoma without re-auditing API availability and restoring any needed fallback paths deliberately.

## Removed Sonoma-Specific Compatibility

The following compatibility paths were removed when Sonoma support ended:

- `SecurityAssessment.swift` now calls `SecCertificateCopyNotValidAfterDate` directly. The old `SecCertificateCopyValues` fallback for certificate expiration dates was only needed for macOS 14 builds.
- `AppScanner.swift` now uses `Storefront.current` for Mac App Store storefront detection. The old `SKPaymentQueue.default().storefront` fallback was only needed below macOS 15.

## Behavior That Should Remain

The subprocess timeout hardening added during the Sonoma audit is not Sonoma-specific and should stay:

- Non-interactive command-line probes use bounded waits.
- Administrator authorization subprocesses use longer bounded waits.
- Timed-out subprocesses are terminated and killed if needed.

This prevents scanner, inventory, and security work from hanging the app if a system command stalls.

## Current Direction

- Minimum supported macOS: 15.0.
- Primary compatibility focus: Sequoia and Tahoe.
- Prefer modern APIs available at the deployment target or newer.
- Gate only features that require APIs newer than macOS 15.
