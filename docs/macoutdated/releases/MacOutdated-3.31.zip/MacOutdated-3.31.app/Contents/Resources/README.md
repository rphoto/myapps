# MacOutdated

## Coding Agent Instructions

For coding assistants and automation tools, [AGENTS.md](./AGENTS.md) is the canonical source of repository instructions and should be read first.

## Xcode Cloud

See [docs/XcodeCloud.md](docs/XcodeCloud.md). Use test plan **MacOutdatedUnit** for CI (unit tests only).
