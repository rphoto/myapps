# Xcode Preview Workaround: libswiftWebKit

## Summary

Xcode Previews used to fail for the `MacOutdated` app target with this error:

```text
Could not analyze the built target description for MacOutdated to create the preview.
CouldNotFindLibrary: Could not find library with name "/usr/lib/swift/libswiftWebKit.dylib"
```

## Root cause

The WebKit Swift overlay (`libswiftWebKit.dylib`) was merged into `WebKit.framework` in macOS 15.4. The SDK's `WebKit.tbd` carries `$ld$previous$/usr/lib/swift/libswiftWebKit.dylib$$1$10.16$15.4$…` mappings, so when the app's deployment target is below 15.4 (ours is 15.0) and the code references an overlay symbol, the linker deliberately emits a load command for the legacy path `/usr/lib/swift/libswiftWebKit.dylib`.

That path exists only in the dyld shared cache, not on disk. The app runs fine, but the Xcode preview analyzer checks the filesystem and fails.

The only overlay symbols we referenced were the Swift conveniences for `WKWebView.find` (`find(_:configuration:)` async and `find(_:configuration:completionHandler:)`), used in `HelpDocumentView.swift`.

## Fix (current)

`HelpDocumentView.swift` calls the raw `NS_REFINED_FOR_SWIFT` ObjC method instead of the Swift overlay:

```swift
let result = await withCheckedContinuation { continuation in
    webView.__find(request.query, with: configuration) { result in
        continuation.resume(returning: result)
    }
}
```

This binds via `objc_msgSend` with no overlay symbol, so the linker emits no `libswiftWebKit` load command at all. Verify with:

```bash
otool -L …/MacOutdated.app/Contents/MacOS/MacOutdated.debug.dylib | grep libswiftWebKit   # no output
xcrun dyld_info -fixups …/MacOutdated.debug.dylib | grep libswiftWebKit                    # no output
```

If a future change reintroduces the failure, find the offending overlay symbol with the `dyld_info -fixups` command above and remove that overlay usage (or raise the deployment target to 15.4+, which removes the `$ld$previous` window entirely).

## Approaches that do NOT work

- **A post-link `install_name_tool -change` script** rewriting the load command to `WebKit.framework`: the debug dylib already links WebKit.framework, so the rewrite creates a duplicate `LC_LOAD_DYLIB` and dyld refuses to load the app (`duplicate linked dylib`). This is what previously "corrupted" Run builds.
- **Guarding such a script to preview-only builds via `TARGET_BUILD_DIR` containing `/Previews/`**: Xcode 26 XOJIT previews analyze the regular `Build/Products/Debug` products — no `Previews/` intermediate directory exists — so the script never fires and previews still fail.
- **Guarding on `ENABLE_PREVIEWS` / `ENABLE_XOJIT_PREVIEWS`**: both are `YES` for all Debug builds, including Run.
- **Explicitly linking `WebKit.framework`** or adding SDK Swift overlay paths to `LIBRARY_SEARCH_PATHS`: neither removes the `$ld$previous`-generated load command.

The former Run Script build phase implementing the rewrite has been removed from the `MacOutdated` target.
