#!/usr/bin/env bash
# Date modified: 2025-08-05
# CURRENT_PROJECT_VERSION: $(CURRENT_PROJECT_VERSION)
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: EnvironmentRestore.sh [--dry-run] [--remove-brew|--remove-pyenv|--remove-all]

Reads a MacOutdated environment snapshot from standard input and restores
Homebrew formulae/casks plus pyenv runtimes and virtual environments.

Options:
  --dry-run       Show what would happen without making changes.
  --remove-brew   Remove Homebrew packages and uninstall Homebrew.
  --remove-pyenv  Remove all pyenv runtimes, virtualenvs, and pyenv install files.
  --remove-all    Remove both Homebrew and pyenv, then exit.
EOF
}

log() {
  printf '%s\n' "$*"
}

fail() {
  printf 'Error: %s\n' "$*" >&2
  exit 1
}

# Predeclare arrays early so set -u never trips on array expansion in functions.
declare -a FORMULAS=()
declare -a CASKS=()
declare -a BREWFILE_LINES=()
declare -a LIFECYCLE_PACKAGE_KINDS=()
declare -a LIFECYCLE_PACKAGE_NAMES=()
declare -a LIFECYCLE_STATUS_KINDS=()
declare -a LIFECYCLE_STATUS_DATES=()
declare -a LIFECYCLE_STATUS_REASONS=()
declare -a PYENV_VERSIONS=()
declare -a PYENV_GLOBAL=()
declare -a PYENV_ORPHAN_VENVS=()
declare -a PYENV_ENV_NAMES=()
declare -a PYENV_ENV_BASES=()
declare -a PYENV_ENV_REQUIREMENTS=()
declare -a FAILED_RESTORE_ITEMS=()
declare -a TEMP_PATHS=()

cleanup_temp_paths() {
  local path
  for path in "${TEMP_PATHS[@]-}"; do
    [[ -n "$path" ]] && rm -f "$path"
  done
}

trap cleanup_temp_paths EXIT

register_temp_path() {
  local path="$1"
  [[ -n "$path" ]] && TEMP_PATHS+=("$path")
}

report_failure() {
  local category="$1"
  local item="$2"
  FAILED_RESTORE_ITEMS+=("$category:$item")
  log "Failed to restore $category: $item"
}

brew_package_is_available() {
  local package_kind="$1"
  local package_name="$2"
  if [[ "$package_kind" == "formula" ]]; then
    brew info --formula "$package_name" >/dev/null 2>&1
  else
    brew info --cask "$package_name" >/dev/null 2>&1
  fi
}

run_cmd() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[dry-run] %s' "$1"
    shift
    for arg in "$@"; do
      printf ' %q' "$arg"
    done
    printf '\n'
    return 0
  fi

  "$@"
}

run_shell() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[dry-run] %s\n' "$1"
    return 0
  fi

  /bin/bash -c "$1"
}

run_shell_with_tty() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[dry-run] %s\n' "$1"
    return 0
  fi

  if [[ -r /dev/tty ]]; then
    /bin/bash -c "$1" </dev/tty
  else
    /bin/bash -c "$1"
  fi
}

OS_NAME="$(uname -s)"
IS_MACOS=0
IS_LINUX=0
case "$OS_NAME" in
  Darwin)
    IS_MACOS=1
    ;;
  Linux)
    IS_LINUX=1
    ;;
esac

ensure_non_root_linuxbrew_context() {
  if [[ "$IS_LINUX" -eq 1 && "${EUID:-$(id -u)}" -eq 0 ]]; then
    fail "Homebrew on Linux must be installed and run as a non-root user. Re-run this script as a regular user with sudo access."
  fi
}

setup_brew_shellenv() {
  if command -v brew >/dev/null 2>&1; then
    eval "$(brew shellenv)"
  elif [[ -x /opt/homebrew/bin/brew ]]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [[ -x /usr/local/bin/brew ]]; then
    eval "$(/usr/local/bin/brew shellenv)"
  elif [[ -x /home/linuxbrew/.linuxbrew/bin/brew ]]; then
    eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
  elif [[ -x "$HOME/.linuxbrew/bin/brew" ]]; then
    eval "$("$HOME/.linuxbrew/bin/brew" shellenv)"
  fi
}

ensure_brew_installed() {
  ensure_non_root_linuxbrew_context
  setup_brew_shellenv
  if command -v brew >/dev/null 2>&1; then
    return 0
  fi

  log "Homebrew is not installed; bootstrapping it."
  run_shell_with_tty '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  setup_brew_shellenv

  if [[ "$DRY_RUN" -eq 0 ]] && ! command -v brew >/dev/null 2>&1; then
    fail "Homebrew installation did not produce a usable brew executable."
  fi
}

ensure_pyenv_installed() {
  local snapshot_has_pyenv_virtualenv=0
  local package_name

  for package_name in "${FORMULAS[@]-}"; do
    if [[ "$(basename "$package_name")" == "pyenv-virtualenv" ]]; then
      snapshot_has_pyenv_virtualenv=1
      break
    fi
  done

  local needs_virtualenv=0
  if [[ "${#PYENV_ENV_NAMES[@]}" -gt 0 ]] || [[ "$snapshot_has_pyenv_virtualenv" -eq 1 ]]; then
    needs_virtualenv=1
  fi

  ensure_brew_installed

  if ! command -v pyenv >/dev/null 2>&1; then
    log "pyenv is not installed; installing it."
    if ! run_cmd brew install pyenv; then
      report_failure "formula" "pyenv"
      return 0
    fi
  fi

  setup_pyenv_environment

  if [[ "$needs_virtualenv" -eq 1 ]]; then
    if ! pyenv commands --no-shims 2>/dev/null | grep -qx "virtualenv"; then
      log "pyenv virtualenv support is required; installing pyenv-virtualenv."
      if ! run_cmd brew install pyenv-virtualenv; then
        report_failure "formula" "pyenv-virtualenv"
        return 0
      fi
      setup_pyenv_environment
    fi

    if ! pyenv commands --no-shims 2>/dev/null | grep -qx "virtualenv"; then
      report_failure "pyenv" "virtualenv-command"
      log "pyenv-virtualenv is installed but the 'pyenv virtualenv' command is unavailable in this shell."
    fi
  fi
}

lifecycle_kind_for() {
  local target_kind="$1"
  local target_name="$2"
  local target_short_name
  target_short_name="$(basename "$target_name")"
  local i
  for ((i = 0; i < ${#LIFECYCLE_PACKAGE_NAMES[@]}; i++)); do
    local lifecycle_name="${LIFECYCLE_PACKAGE_NAMES[$i]}"
    local lifecycle_short_name
    lifecycle_short_name="$(basename "$lifecycle_name")"
    if [[ "${LIFECYCLE_PACKAGE_KINDS[$i]}" == "$target_kind" ]] && \
       ([[ "$lifecycle_name" == "$target_name" ]] || [[ "$lifecycle_short_name" == "$target_short_name" ]]); then
      printf '%s' "${LIFECYCLE_STATUS_KINDS[$i]}"
      return 0
    fi
  done
  return 1
}

lifecycle_detail_for() {
  local target_kind="$1"
  local target_name="$2"
  local target_short_name
  target_short_name="$(basename "$target_name")"
  local i
  for ((i = 0; i < ${#LIFECYCLE_PACKAGE_NAMES[@]}; i++)); do
    local lifecycle_name="${LIFECYCLE_PACKAGE_NAMES[$i]}"
    local lifecycle_short_name
    lifecycle_short_name="$(basename "$lifecycle_name")"
    if [[ "${LIFECYCLE_PACKAGE_KINDS[$i]}" == "$target_kind" ]] && \
       ([[ "$lifecycle_name" == "$target_name" ]] || [[ "$lifecycle_short_name" == "$target_short_name" ]]); then
      local detail="${LIFECYCLE_STATUS_KINDS[$i]}"
      if [[ -n "${LIFECYCLE_STATUS_DATES[$i]}" ]]; then
        detail="${detail} ${LIFECYCLE_STATUS_DATES[$i]}"
      fi
      if [[ -n "${LIFECYCLE_STATUS_REASONS[$i]}" ]]; then
        detail="${detail} ${LIFECYCLE_STATUS_REASONS[$i]}"
      fi
      printf '%s' "$detail"
      return 0
    fi
  done
  return 1
}

append_pyenv_requirement() {
  local env_name="$1"
  local requirement="$2"
  local i
  for ((i = 0; i < ${#PYENV_ENV_NAMES[@]}; i++)); do
    if [[ "${PYENV_ENV_NAMES[$i]}" == "$env_name" ]]; then
      if [[ -n "${PYENV_ENV_REQUIREMENTS[$i]}" ]]; then
        PYENV_ENV_REQUIREMENTS[$i]+=$'\n'
      fi
      PYENV_ENV_REQUIREMENTS[$i]+="$requirement"
      return 0
    fi
  done
}

requirements_pin_python_packaging_tools() {
  local requirements_text="$1"
  local requirement_line
  while IFS= read -r requirement_line; do
    requirement_line="${requirement_line%%#*}"
    requirement_line="$(printf '%s' "$requirement_line" | tr -d '[:space:]')"
    [[ -z "$requirement_line" ]] && continue
    case "$requirement_line" in
      pip==*|pip===*|setuptools==*|setuptools===*|wheel==*|wheel===*)
        return 0
        ;;
    esac
  done <<< "$requirements_text"
  return 1
}

remove_existing_homebrew_state() {
  ensure_non_root_linuxbrew_context
  if ! command -v brew >/dev/null 2>&1; then
    log "No existing Homebrew installation detected."
    return 0
  fi

  local formula
  while IFS= read -r formula; do
    [[ -z "$formula" ]] && continue
    if ! run_cmd brew uninstall --ignore-dependencies --force "$formula"; then
      report_failure "formula removal" "$formula"
    fi
  done <<< "$(brew list --formula 2>/dev/null || true)"

  local cask
  if [[ "$IS_MACOS" -eq 1 ]]; then
    while IFS= read -r cask; do
      [[ -z "$cask" ]] && continue
      if ! run_cmd brew uninstall --cask --force "$cask"; then
        report_failure "cask removal" "$cask"
      fi
    done <<< "$(brew list --cask 2>/dev/null || true)"
  fi

  if ! run_cmd brew cleanup; then
    report_failure "brew cleanup" "cleanup"
  fi
}

remove_homebrew_installation() {
  ensure_non_root_linuxbrew_context
  setup_brew_shellenv

  if command -v brew >/dev/null 2>&1; then
    log "Removing installed Homebrew packages."
    remove_existing_homebrew_state

    local uninstall_script
    uninstall_script="$(brew --repository 2>/dev/null || true)/Library/Homebrew/uninstall.sh"
    if [[ -n "${uninstall_script%%/Library/Homebrew/uninstall.sh}" && -f "$uninstall_script" ]]; then
      log "Running Homebrew uninstall script."
      if ! run_cmd /bin/bash "$uninstall_script" -f; then
        report_failure "brew" "uninstall-script"
      fi
    else
      log "Homebrew uninstall script not found locally; using official uninstall script."
      if ! run_shell_with_tty '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/uninstall.sh)" -- -f'; then
        report_failure "brew" "uninstall-script"
      fi
    fi
  else
    log "No existing Homebrew installation detected."
  fi

  # Best-effort cleanup for common Homebrew directories.
  local common_brew_dirs=(
    "/opt/homebrew"
    "/usr/local/Homebrew"
    "/home/linuxbrew/.linuxbrew"
    "$HOME/.linuxbrew"
  )
  local brew_dir
  for brew_dir in "${common_brew_dirs[@]}"; do
    if [[ -d "$brew_dir" ]]; then
      if [[ "$DRY_RUN" -eq 1 ]]; then
        run_cmd rm -rf "$brew_dir"
      elif [[ -w "$brew_dir" || -w "$(dirname "$brew_dir")" ]]; then
        if ! run_cmd rm -rf "$brew_dir"; then
          log "Could not remove $brew_dir automatically. You may need to remove it manually."
        fi
      else
        log "Skipping $brew_dir cleanup due to permissions (manual removal may require sudo)."
      fi
    fi
  done
}

restore_homebrew_state() {
  local formulas_to_install=()
  local casks_to_install=()
  local available_formulas=()
  local available_casks=()
  local package_name
  local lifecycle_kind
  local lifecycle_detail
  local brewfile_path
  local failed_homebrew=0

  for package_name in "${FORMULAS[@]-}"; do
    [[ -z "$package_name" ]] && continue
    lifecycle_kind="$(lifecycle_kind_for formula "$package_name" || true)"
    if [[ "$lifecycle_kind" == "disabled" ]]; then
      lifecycle_detail="$(lifecycle_detail_for formula "$package_name" || true)"
      log "Skipping disabled formula $package_name${lifecycle_detail:+ ($lifecycle_detail)}."
      continue
    fi
    if [[ "$lifecycle_kind" == "deprecated" ]]; then
      lifecycle_detail="$(lifecycle_detail_for formula "$package_name" || true)"
      log "Restoring deprecated formula $package_name${lifecycle_detail:+ ($lifecycle_detail)}."
    fi
    formulas_to_install+=("$package_name")
  done

  for package_name in "${CASKS[@]-}"; do
    [[ -z "$package_name" ]] && continue
    if [[ "$IS_MACOS" -ne 1 ]]; then
      log "Skipping cask $package_name because Homebrew casks are only restorable on macOS."
      continue
    fi
    lifecycle_kind="$(lifecycle_kind_for cask "$package_name" || true)"
    if [[ "$lifecycle_kind" == "disabled" ]]; then
      lifecycle_detail="$(lifecycle_detail_for cask "$package_name" || true)"
      log "Skipping disabled cask $package_name${lifecycle_detail:+ ($lifecycle_detail)}."
      continue
    fi
    if [[ "$lifecycle_kind" == "deprecated" ]]; then
      lifecycle_detail="$(lifecycle_detail_for cask "$package_name" || true)"
      log "Restoring deprecated cask $package_name${lifecycle_detail:+ ($lifecycle_detail)}."
    fi
    casks_to_install+=("$package_name")
  done

  if [[ "${#formulas_to_install[@]}" -eq 0 && "${#casks_to_install[@]}" -eq 0 ]]; then
    log "Snapshot does not declare any restorable Homebrew formulae or casks; preserving the existing Homebrew state."
    return 0
  fi

  ensure_brew_installed
  setup_brew_shellenv

  if [[ "${#formulas_to_install[@]}" -gt 0 ]]; then
    for package_name in "${formulas_to_install[@]}"; do
      if [[ "$DRY_RUN" -eq 0 ]] && ! brew_package_is_available formula "$package_name"; then
        report_failure "formula unavailable" "$package_name"
        continue
      fi
      available_formulas+=("$package_name")
    done
  fi

  if [[ "${#casks_to_install[@]}" -gt 0 ]]; then
    for package_name in "${casks_to_install[@]}"; do
      if [[ "$DRY_RUN" -eq 0 ]] && ! brew_package_is_available cask "$package_name"; then
        report_failure "cask unavailable" "$package_name"
        continue
      fi
      available_casks+=("$package_name")
    done
  fi

  if [[ "${#available_formulas[@]}" -eq 0 && "${#available_casks[@]}" -eq 0 ]]; then
    log "No Homebrew packages from the snapshot are currently restorable; preserving the existing Homebrew state."
    return 0
  fi

  brewfile_path="$(mktemp "${TMPDIR:-/tmp}/macoutdated-brewfile.XXXXXX")"
  register_temp_path "$brewfile_path"
  {
    local tap_name
    while IFS= read -r tap_name; do
      [[ -n "$tap_name" ]] && printf 'tap "%s"\n' "$tap_name"
    done < <(printf '%s\n' "${BREWFILE_LINES[@]-}" | sed -n 's/^tap "\(.*\)"$/\1/p')
    if [[ "${#available_formulas[@]}" -gt 0 && "${#available_casks[@]}" -gt 0 ]]; then
      printf '\n'
    fi
    for package_name in "${available_formulas[@]}"; do
      printf 'brew "%s"\n' "$package_name"
    done
    if [[ "${#available_formulas[@]}" -gt 0 && "${#available_casks[@]}" -gt 0 ]]; then
      printf '\n'
    fi
    for package_name in "${available_casks[@]}"; do
      printf 'cask "%s"\n' "$package_name"
    done
  } >"$brewfile_path"

  # Skip the destructive remove+reinstall if the existing state already satisfies
  # the snapshot. brew bundle check exits 0 when every dependency is installed.
  if [[ "$DRY_RUN" -eq 0 ]] && brew bundle check --file="$brewfile_path" >/dev/null 2>&1; then
    log "Homebrew state already satisfies snapshot; no changes needed."
    return 0
  fi

  remove_existing_homebrew_state

  if [[ "$DRY_RUN" -eq 1 ]]; then
    log "[dry-run] Brewfile contents:"
    cat "$brewfile_path"
    run_cmd brew bundle install --file="$brewfile_path"
  elif ! brew bundle install --file="$brewfile_path"; then
    log "Brewfile install failed; retrying packages individually with tap fallback."
    local pkg base_name
    for pkg in "${available_formulas[@]}"; do
      if ! brew install "$pkg"; then
        base_name="$(basename "$pkg")"
        if [[ "$base_name" != "$pkg" ]]; then
          log "  $pkg failed; trying $base_name without tap prefix."
          if ! brew install "$base_name"; then
            report_failure "formula" "$pkg"
            failed_homebrew=1
          fi
        else
          report_failure "formula" "$pkg"
          failed_homebrew=1
        fi
      fi
    done
    for pkg in "${available_casks[@]}"; do
      if ! brew install --cask "$pkg"; then
        base_name="$(basename "$pkg")"
        if [[ "$base_name" != "$pkg" ]]; then
          log "  $pkg failed; trying $base_name without tap prefix."
          if ! brew install --cask "$base_name"; then
            report_failure "cask" "$pkg"
            failed_homebrew=1
          fi
        else
          report_failure "cask" "$pkg"
          failed_homebrew=1
        fi
      fi
    done
  fi

  if [[ "$failed_homebrew" -eq 1 ]]; then
    log "Homebrew restore completed with some package failures."
  fi
}

setup_pyenv_environment() {
  ensure_non_root_linuxbrew_context
  export PYENV_ROOT="${PYENV_ROOT:-$HOME/.pyenv}"
  export PATH="$PYENV_ROOT/bin:$PATH"
  if command -v pyenv >/dev/null 2>&1; then
    eval "$(pyenv init -)"
    eval "$(pyenv virtualenv-init -)" || true
  fi
}

remove_existing_pyenv_state() {
  local pyenv_root="${PYENV_ROOT:-$HOME/.pyenv}"
  if [[ -d "$pyenv_root/versions" ]]; then
    run_cmd rm -rf "$pyenv_root/versions"
  fi
  if [[ -f "$pyenv_root/version" ]]; then
    run_cmd rm -f "$pyenv_root/version"
  fi
}

remove_pyenv_installation() {
  local pyenv_root="${PYENV_ROOT:-$HOME/.pyenv}"
  if [[ -d "$pyenv_root" ]]; then
    log "Removing pyenv directory at $pyenv_root."
    run_cmd rm -rf "$pyenv_root"
  else
    log "No pyenv root directory found at $pyenv_root."
  fi

  setup_brew_shellenv
  if command -v brew >/dev/null 2>&1; then
    local formula
    for formula in pyenv pyenv-virtualenv; do
      if brew list --formula "$formula" >/dev/null 2>&1; then
        if ! run_cmd brew uninstall --ignore-dependencies --force "$formula"; then
          report_failure "formula" "$formula"
        fi
      fi
    done
  fi
}

restore_pyenv_state() {
  if [[ "$PYENV_STATE" != "present" ]]; then
    log "Snapshot does not include pyenv state; clearing existing pyenv runtimes and virtual environments."
    setup_pyenv_environment
    remove_existing_pyenv_state
    return 0
  fi

  ensure_pyenv_installed
  setup_pyenv_environment
  if [[ "$DRY_RUN" -eq 0 ]] && ! command -v pyenv >/dev/null 2>&1; then
    report_failure "pyenv" "bootstrap"
    log "Skipping pyenv restore because pyenv is still unavailable after bootstrap."
    return 0
  fi

  # If the installed versions already match the snapshot, only update the global
  # rather than wiping and reinstalling every runtime.
  if [[ "$DRY_RUN" -eq 0 ]] && command -v pyenv >/dev/null 2>&1; then
    local current_versions target_versions
    current_versions="$(pyenv versions --bare 2>/dev/null | grep -v '^system$' | grep -v '/envs/' | sort || true)"
    target_versions="$(printf '%s\n' "${PYENV_VERSIONS[@]:-}" | sort || true)"
    if [[ "$current_versions" == "$target_versions" ]]; then
      if [[ "${#PYENV_ORPHAN_VENVS[@]}" -gt 0 ]]; then
        local orphan_base orphan_name
        orphan_base="${PYENV_VERSIONS[0]:-}"
        if [[ -z "$orphan_base" ]]; then
          orphan_base="$(pyenv versions --bare 2>/dev/null | grep -v '^system$' | grep -v '/envs/' | head -1 || true)"
        fi
        for orphan_name in "${PYENV_ORPHAN_VENVS[@]}"; do
          [[ -z "$orphan_name" ]] && continue
          if pyenv versions --bare 2>/dev/null | grep -qxF "$orphan_name"; then
            log "Virtualenv $orphan_name already exists; skipping."
          elif [[ -z "$orphan_base" ]]; then
            log "Cannot create virtualenv $orphan_name: no Python version available as base."
            report_failure "pyenv virtualenv" "$orphan_name"
          else
            log "Creating virtualenv $orphan_name from old snapshot format (base: $orphan_base)."
            if ! run_cmd pyenv virtualenv "$orphan_base" "$orphan_name"; then
              report_failure "pyenv virtualenv" "$orphan_name"
            fi
          fi
        done
      fi
      if [[ "${#PYENV_GLOBAL[@]}" -gt 0 ]]; then
        local current_global
        current_global="$(pyenv global 2>/dev/null || true)"
        if [[ "${PYENV_GLOBAL[*]}" != "$current_global" ]]; then
          log "pyenv versions already match snapshot; updating global only."
          if ! run_cmd pyenv global "${PYENV_GLOBAL[@]}"; then
            report_failure "pyenv global" "${PYENV_GLOBAL[*]}"
          fi
        else
          log "pyenv state already matches snapshot; no changes needed."
        fi
      else
        log "pyenv versions already match snapshot; no changes needed."
      fi
      return 0
    fi
  fi

  remove_existing_pyenv_state

  local version
  for version in "${PYENV_VERSIONS[@]-}"; do
    [[ -z "$version" ]] && continue
    if ! run_cmd pyenv install -s "$version"; then
      report_failure "pyenv version" "$version"
    fi
  done

  local i
  local pyenv_virtualenv_available=1
  if [[ "${#PYENV_ENV_NAMES[@]}" -gt 0 ]] && ! pyenv commands --no-shims 2>/dev/null | grep -qx "virtualenv"; then
    pyenv_virtualenv_available=0
    report_failure "pyenv" "virtualenv-command"
    log "Cannot restore pyenv virtualenvs because the 'pyenv virtualenv' command is unavailable."
  fi

  for ((i = 0; i < ${#PYENV_ENV_NAMES[@]}; i++)); do
    if [[ "$pyenv_virtualenv_available" -eq 0 ]]; then
      report_failure "pyenv virtualenv" "${PYENV_ENV_NAMES[$i]}"
      continue
    fi
    if ! run_cmd env "PYENV_VERSION=${PYENV_ENV_BASES[$i]}" pyenv virtualenv "${PYENV_ENV_BASES[$i]}" "${PYENV_ENV_NAMES[$i]}"; then
      report_failure "pyenv virtualenv" "${PYENV_ENV_NAMES[$i]}"
    fi
  done

  if [[ "${#PYENV_ORPHAN_VENVS[@]}" -gt 0 ]]; then
    local orphan_venv_ok=1
    if ! pyenv commands --no-shims 2>/dev/null | grep -qx "virtualenv"; then
      orphan_venv_ok=0
    fi
    local orphan_base="${PYENV_VERSIONS[0]:-}"
    local orphan_name
    for orphan_name in "${PYENV_ORPHAN_VENVS[@]}"; do
      [[ -z "$orphan_name" ]] && continue
      if [[ "$orphan_venv_ok" -eq 0 ]]; then
        report_failure "pyenv virtualenv" "$orphan_name"
      elif [[ -z "$orphan_base" ]]; then
        log "Cannot create virtualenv $orphan_name: no Python version available as base."
        report_failure "pyenv virtualenv" "$orphan_name"
      else
        log "Creating virtualenv $orphan_name from old snapshot format (base: $orphan_base)."
        if ! run_cmd pyenv virtualenv "$orphan_base" "$orphan_name"; then
          report_failure "pyenv virtualenv" "$orphan_name"
        fi
      fi
    done
  fi

  for ((i = 0; i < ${#PYENV_ENV_NAMES[@]}; i++)); do
    if [[ -z "${PYENV_ENV_REQUIREMENTS[$i]}" ]]; then
      continue
    fi
    local should_upgrade_packaging_tools=1
    if requirements_pin_python_packaging_tools "${PYENV_ENV_REQUIREMENTS[$i]}"; then
      should_upgrade_packaging_tools=0
    fi
    if [[ "$DRY_RUN" -eq 1 ]]; then
      if [[ "$should_upgrade_packaging_tools" -eq 1 ]]; then
        printf '[dry-run] PYENV_VERSION=%q pyenv exec python -m pip install --upgrade pip setuptools wheel\n' "${PYENV_ENV_NAMES[$i]}"
      fi
      printf '[dry-run] write requirements for %q to a temporary file and run: PYENV_VERSION=%q pyenv exec python -m pip install -r <tempfile>\n' "${PYENV_ENV_NAMES[$i]}" "${PYENV_ENV_NAMES[$i]}"
      printf '%s\n' "${PYENV_ENV_REQUIREMENTS[$i]}"
    else
      local requirements_file
      requirements_file="$(mktemp "${TMPDIR:-/tmp}/macoutdated-pyenv-req.XXXXXX.txt")"
      register_temp_path "$requirements_file"
      printf '%s\n' "${PYENV_ENV_REQUIREMENTS[$i]}" > "$requirements_file"
      if [[ "$should_upgrade_packaging_tools" -eq 1 ]]; then
        if ! env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip install --upgrade pip setuptools wheel; then
          report_failure "pyenv bootstrap" "${PYENV_ENV_NAMES[$i]}"
        fi
      fi
      if ! env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip install -r "$requirements_file"; then
        log "Batch install failed for ${PYENV_ENV_NAMES[$i]}; purging pip cache and retrying."
        env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip cache purge 2>/dev/null || true
        if env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip install -r "$requirements_file"; then
          continue
        fi
        log "Retry failed; installing packages individually with version fallback."
        local req pkg_name
        while IFS= read -r req || [[ -n "$req" ]]; do
          req="${req%%#*}"
          req="$(printf '%s' "$req" | tr -d '[:space:]')"
          [[ -z "$req" ]] && continue
          if ! env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip install "$req" 2>/dev/null; then
            pkg_name="${req%%[>=<!~@]*}"
            if [[ "$pkg_name" != "$req" && -n "$pkg_name" ]]; then
              log "  $req unavailable at that version; installing $pkg_name without version constraint."
              if ! env "PYENV_VERSION=${PYENV_ENV_NAMES[$i]}" pyenv exec python -m pip install "$pkg_name"; then
                report_failure "pyenv requirement" "${PYENV_ENV_NAMES[$i]}:$pkg_name"
              fi
            else
              report_failure "pyenv requirement" "${PYENV_ENV_NAMES[$i]}:$req"
            fi
          fi
        done < "$requirements_file"
      fi
    fi
  done

  if [[ "${#PYENV_GLOBAL[@]}" -gt 0 ]]; then
    if ! run_cmd pyenv global "${PYENV_GLOBAL[@]}"; then
      report_failure "pyenv global" "${PYENV_GLOBAL[*]}"
    fi
  fi
}

DRY_RUN=0
REMOVE_BREW=0
REMOVE_PYENV=0
FAILED_RESTORE_ITEMS=()
for arg in "$@"; do
  case "$arg" in
    --dry-run)
      DRY_RUN=1
      ;;
    --remove-brew)
      REMOVE_BREW=1
      ;;
    --remove-pyenv)
      REMOVE_PYENV=1
      ;;
    --remove-all)
      REMOVE_BREW=1
      REMOVE_PYENV=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      fail "Unknown option: $arg"
      ;;
  esac
done

if [[ "$REMOVE_BREW" -eq 1 || "$REMOVE_PYENV" -eq 1 ]]; then
  if [[ "$DRY_RUN" -eq 0 && "${MACOUTDATED_SKIP_CONFIRM:-0}" -ne 1 ]]; then
    if [[ "$REMOVE_BREW" -eq 1 && "$REMOVE_PYENV" -eq 1 ]]; then
      log "This will remove Homebrew and pyenv from this machine."
    elif [[ "$REMOVE_BREW" -eq 1 ]]; then
      log "This will remove Homebrew from this machine."
    else
      log "This will remove pyenv from this machine."
    fi
    read -r -p "Continue? [y/N] " confirmation
    if [[ ! "$confirmation" =~ ^[Yy]$ ]]; then
      log "Removal cancelled."
      exit 0
    fi
  elif [[ "$DRY_RUN" -eq 1 ]]; then
    log "Dry run: no changes will be made."
  fi

  if [[ "$REMOVE_BREW" -eq 1 ]]; then
    remove_homebrew_installation
  fi
  if [[ "$REMOVE_PYENV" -eq 1 ]]; then
    remove_pyenv_installation
  fi

  if [[ "${#FAILED_RESTORE_ITEMS[@]}" -gt 0 ]]; then
    log ""
    log "Removal completed with failures:"
    for item in "${FAILED_RESTORE_ITEMS[@]}"; do
      log "  - $item"
    done
    if [[ "$DRY_RUN" -eq 1 ]]; then
      log "Dry run complete with failures."
    else
      fail "Removal completed with failures."
    fi
  fi

  if [[ "$DRY_RUN" -eq 1 ]]; then
    log "Dry run complete."
  else
    log "Removal complete."
  fi
  exit 0
fi

FORMULAS=()
CASKS=()
BREWFILE_LINES=()
LIFECYCLE_PACKAGE_KINDS=()
LIFECYCLE_PACKAGE_NAMES=()
LIFECYCLE_STATUS_KINDS=()
LIFECYCLE_STATUS_DATES=()
LIFECYCLE_STATUS_REASONS=()
PYENV_STATE="absent"
PYENV_VERSIONS=()
PYENV_GLOBAL=()
PYENV_ORPHAN_VENVS=()
PYENV_ENV_NAMES=()
PYENV_ENV_BASES=()
PYENV_ENV_REQUIREMENTS=()

header_seen=0
current_section=""
while IFS= read -r line || [[ -n "$line" ]]; do
  [[ -z "$line" ]] && continue

  if [[ "$header_seen" -eq 0 ]]; then
    [[ "$line" == "MACOUTDATED_ENV_RESTORE_INPUT_V1" ]] || fail "Input does not look like MacOutdated restore data."
    header_seen=1
    continue
  fi

  case "$line" in
    "[brewfile]"|"[formulas]"|"[casks]"|"[lifecycle]"|"[pyenv]")
      current_section="${line#[}"
      current_section="${current_section%]}"
      continue
      ;;
    "[/brewfile]"|"[/formulas]"|"[/casks]"|"[/lifecycle]"|"[/pyenv]")
      current_section=""
      continue
      ;;
  esac

  case "$current_section" in
    brewfile)
      BREWFILE_LINES+=("$line")
      ;;
    formulas)
      FORMULAS+=("$line")
      ;;
    casks)
      CASKS+=("$line")
      ;;
    lifecycle)
      IFS='|' read -r package_kind status_kind package_name status_date status_reason <<< "$line"
      [[ -n "${package_kind:-}" && -n "${status_kind:-}" && -n "${package_name:-}" ]] || continue
      LIFECYCLE_PACKAGE_KINDS+=("$package_kind")
      LIFECYCLE_STATUS_KINDS+=("$status_kind")
      LIFECYCLE_PACKAGE_NAMES+=("$package_name")
      LIFECYCLE_STATUS_DATES+=("${status_date:-}")
      LIFECYCLE_STATUS_REASONS+=("${status_reason:-}")
      ;;
    pyenv)
      case "$line" in
        state=*)
          PYENV_STATE="${line#state=}"
          ;;
        version=*)
          pyenv_version_candidate="${line#version=}"
          case "$pyenv_version_candidate" in
            system|[0-9]*)
              PYENV_VERSIONS+=("$pyenv_version_candidate")
              ;;
            *)
              PYENV_ORPHAN_VENVS+=("$pyenv_version_candidate")
              ;;
          esac
          ;;
        global=*)
          PYENV_GLOBAL+=("${line#global=}")
          ;;
        venv=*)
          venv_payload="${line#venv=}"
          IFS='|' read -r env_name env_base <<< "$venv_payload"
          [[ -n "${env_name:-}" && -n "${env_base:-}" ]] || continue
          PYENV_ENV_NAMES+=("$env_name")
          PYENV_ENV_BASES+=("$env_base")
          PYENV_ENV_REQUIREMENTS+=("")
          ;;
        requirement=*)
          requirement_payload="${line#requirement=}"
          IFS='|' read -r env_name requirement <<< "$requirement_payload"
          [[ -n "${env_name:-}" && -n "${requirement:-}" ]] || continue
          append_pyenv_requirement "$env_name" "$requirement"
          ;;
      esac
      ;;
  esac
done

[[ "$header_seen" -eq 1 ]] || fail "No environment restore data was provided on standard input."

if [[ "$DRY_RUN" -eq 0 && "${MACOUTDATED_SKIP_CONFIRM:-0}" -ne 1 ]]; then
  log "This will replace your current Homebrew and pyenv environment with the snapshot from stdin."
  read -r -p "Continue? [y/N] " confirmation
  if [[ ! "$confirmation" =~ ^[Yy]$ ]]; then
    log "Restore cancelled."
    exit 0
  fi
elif [[ "$DRY_RUN" -eq 1 ]]; then
  log "Dry run: no changes will be made."
fi

restore_homebrew_state
restore_pyenv_state

if [[ "${#FAILED_RESTORE_ITEMS[@]}" -gt 0 ]]; then
  log ""
  log "Restore completed with failures:"
  for item in "${FAILED_RESTORE_ITEMS[@]}"; do
    log "  - $item"
  done
  if [[ "$DRY_RUN" -eq 1 ]]; then
    log "Dry run complete with failures."
  else
    fail "Restore completed with failures."
  fi
fi

if [[ "$DRY_RUN" -eq 1 ]]; then
  log "Dry run complete."
else
  log "Restore complete."
fi
