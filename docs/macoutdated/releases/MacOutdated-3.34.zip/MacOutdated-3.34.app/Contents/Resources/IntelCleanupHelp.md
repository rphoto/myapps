# Intel Cleanup

Intel Cleanup lives on the **Cleanup Candidates** page under the **Intel Components** tab.

Intel Cleanup finds Intel-only macOS components that can keep showing up after an Apple Silicon migration. It groups those components into reviewed product recipes when possible, and into inferred review groups when MacOutdated can only prove structural ownership.

Every group starts as Keep. Use Remove only after reviewing the product, paths, source, confidence, and notes. Embedded helpers and installer infrastructure are shown for review but are not removed independently.

Preview builds the exact deletion list without changing files. Apply Removal asks for administrator authorization and uses the same target list logic as Preview. User data is kept unless Include user data is enabled for selected groups that define reviewed user-data paths.

Right-click a component with a bundle identifier and choose Show Product Residue to see everything MacOutdated associates with that product across launch items, user Library residue, and privileged locations.
