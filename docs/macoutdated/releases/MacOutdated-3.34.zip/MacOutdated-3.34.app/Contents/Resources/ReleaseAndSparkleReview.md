# MacOutdated — Release, Appcast & Sparkle Review by Cursor

**Date:** May 2026  
**Scope:** MacOutdated app repo + `myapps` release/appcast repo  
**Purpose:** Consolidated architecture notes, risk findings, and suggested fixes from a read-only review. Use this as a runbook reference; nothing here is applied automatically.

### Resolution status (May 2026 update)

Updates applied in `myapps/scripts/release.sh` and `myapps/docs/macoutdated/appcast-macoutdated.xml` unless noted.

| ID | Finding | Status |
|----|---------|--------|
| H1 | Notarization / stapling not in release script | **Open** — use manual notarize/staple before release, or `--require-notarized` |
| H2 | Appcast `minimumSystemVersion` 15.6 vs deployment 15.0 | **Resolved** — `register_app` and appcast items use **15.0** |
| H3 | `git commit` failure leaves artifacts (`set -e`) | **Resolved** — recovery instructions + non-zero exit |
| H4 | Exit 0 outside git repo after writing artifacts | **Resolved** — requires git before mutating files |
| H5 | `Updater` Copy Files may embed wrong artifact | **Open** — verify Release `.app` bundle layout |
| M1 | Sparkle CLI path machine-specific | **Open** — document `SPARKLE_BIN` |
| M2 | No codesign preflight on exported `.app` | **Resolved** — `codesign --verify` + Developer ID + team check |
| M3 | No `git push` / deploy verification | **Partial** — optional `--push` + appcast `curl` probe |

Re-check version numbers in §1 against current `MARKETING_VERSION` / appcast before each release.

---

## 1. How the pieces fit together

MacOutdated auto-update is split across two repositories:

| Role | Repository / path |
|------|-------------------|
| **App source, Sparkle consumer config, embedded framework** | This repo (`MacOutdated/`) |
| **Release script, appcast XML, zip artifacts, release notes** | [`myapps`](https://github.com/rphoto/myapps) — local path: `~/Documents/git-repo-2025/myapps/myapps/` |

### Consumer (this repo)

| Piece | Path |
|-------|------|
| App entry + Sparkle startup | `MacOutdated/MacOutdatedApp.swift` |
| Sparkle settings UI | `MacOutdated/HelpOnboardingView.swift` |
| Third-party app Sparkle updates | `MacOutdated/SparkleSupport.swift`, `MacOutdated/ScannerViewModel.swift` |
| Feed URL & public EdDSA key | `MacOutdated/Info.plist` |
| Vendored Sparkle 2.9.3 | `Sparkle-2.9.3/` |
| Xcode embed + build versions | `MacOutdated.xcodeproj/project.pbxproj` |

**Feed URL (production):**  
`https://rphoto.github.io/myapps/macoutdated/appcast-macoutdated.xml`  
(`MacOutdated/Info.plist` → `SUFeedURL`)

### Connectivity (scan gating & Sparkle fetches)

- **Online** means `NWPathMonitor` path is satisfied **and** a captive-portal probe to `https://captive.apple.com/hotspot-detect.html` returns HTTP 200 with body containing `Success` (`PublicInternetConnectivity.swift`). Tailscale-only paths without public Internet are treated as offline (same UI copy as Wi‑Fi off).
- Version-check HTTP uses an ephemeral `URLSession` via `NetworkFetchSupport.swift` (not `URLSession.shared`).
- Re-probes run on path updates (debounced), every ~30 s while offline with a satisfied path, and before `startScan()` when the last success is older than ~15 s.
- Automated tests skip the live probe when `ScannerViewModel.isRunningAutomatedTests` is true.

**Version alignment:** Compare `MARKETING_VERSION` / `CURRENT_PROJECT_VERSION` in `MacOutdated.xcodeproj` with the latest `<item>` in the appcast before releasing. (This review was written at **2.81 / build 281**.)

### Publisher (`myapps` repo)

| Piece | Path |
|-------|------|
| **Release script** | `myapps/scripts/release.sh` |
| **Appcast** | `myapps/docs/macoutdated/appcast-macoutdated.xml` |
| **Zips** | `myapps/docs/macoutdated/releases/MacOutdated-{version}.zip` |
| **Release notes** | `myapps/docs/macoutdated/notes/{version}.html` |
| Sparkle dSYMs only (no `bin/`) | `myapps/Sparkle/` |

**Run a release:**

```bash
cd /path/to/myapps/myapps
./scripts/release.sh macoutdated /path/to/Exported/MacOutdated.app
# Dry run:
./scripts/release.sh --dry-run macoutdated /path/to/Exported/MacOutdated.app
```

Requires Sparkle CLI tools at `$SPARKLE_BIN` (default `$HOME/Developer/Sparkle/bin`, must contain `sign_update`).

---

## 2. Release pipeline (what `release.sh` does)

Source: `myapps/scripts/release.sh` (header comments still say `release-unified.sh`).

1. Validates `.app` path and reads `CFBundleShortVersionString` / `CFBundleVersion` from the exported app.
2. Prompts for release-note bullet items (interactive).
3. Zips with `ditto` → `docs/macoutdated/releases/MacOutdated-{shortVersion}.zip`.
4. Signs zip with `sign_update` (EdDSA, keychain) → `sparkle:edSignature` + `length`.
5. Writes/updates `notes/{shortVersion}.html` (with optional “Previous versions” rollup).
6. Creates/updates `appcast-macoutdated.xml` (repair dedupe → remove same short version → insert new `<item>` after `<language>`).
7. `git add` zip + notes + appcast, `git commit` with message `Release MacOutdated {version} (build {build})`.

**Not done by the script:** codesign verification, notarization, stapling, `git push`, GitHub Pages deploy verification.

---

## 3. Findings — High

### H1. No notarization or stapling in the release pipeline

**Where:** `myapps/scripts/release.sh` (zip lines ~241–248, sign lines ~252–257). No `notarytool` / `stapler` / `spctl` anywhere in `myapps/`.

**Risk:** Sparkle can ship an update that passes EdDSA signature check but fails Gatekeeper on first launch (signed but not notarized).

**Suggested fix:**

- After Xcode **Archive → Export** (Developer ID), before running `release.sh`:
  - `codesign --verify --deep --strict /path/to/MacOutdated.app`
  - Notarize the `.app` or the zip, then `stapler staple`
- Optionally add these as a documented preflight block or flags in `release.sh` (`--require-notarized`).

---

### H2. `minimumSystemVersion` in appcast (15.6) ≠ Xcode deployment target (15.0)

**Status: Resolved (May 2026).** `release.sh` `register_app` for `macoutdated` uses **15.0**; `repair_appcast_structure` rewrites item minimums to match; live appcast items updated to **15.0**.

Original risk: Sparkle withheld updates from macOS 15.0–15.5 while the binary targeted 15.0.

---

### H3. `git commit` failure leaves artifacts on disk (`set -e`)

**Status: Resolved (May 2026).** On commit failure the script prints recovery steps (`git status`, paths, suggested `git commit`) and exits non-zero. Empty staged changes skip commit with a warning.

---

### H4. Exit 0 when not inside a git repo (artifacts written, no commit)

**Status: Resolved (May 2026).** `require_git_repo` runs before writing release artifacts; missing git is a hard error.

---

### H5. MacOutdated Xcode: `Updater` Copy Files may embed wrong artifact

**Where:** `MacOutdated.xcodeproj/project.pbxproj`

- File reference: `Sparkle-2.9.3/Sparkle.framework/Versions/B/Updater.app/Contents/MacOS/Updater` (Mach-O only).
- Copy Files phase copies into `Contents/Frameworks/` (`dstSubfolderSpec = 10`).

Sparkle’s test app bundles **`Updater.app`** inside the framework, not a bare `Frameworks/Updater` executable.

**Risk:** Sparkle self-update install failures despite a correct appcast.

**Suggested fix:** Inspect a **Release** `MacOutdated.app` bundle. If `Contents/Frameworks/Updater.app` is missing, embed the full `Updater.app` or remove the redundant copy phase if the embedded framework copy is sufficient.

---

## 4. Findings — Medium

### M1. Sparkle CLI path is machine-specific; incomplete copy in `myapps`

| Location | Contents |
|----------|----------|
| `release.sh` default | `$HOME/Developer/Sparkle/bin` |
| `myapps/Sparkle/` | dSYMs only — no `sign_update` |
| `MacOutdated/Sparkle-2.9.3/bin/` | Includes modern `sign_update` plus deprecated DSA scripts |

**Risk:** Release fails on a new machine; wrong Sparkle version vs app-linked 2.9.3.

**Suggested fix:** Document required Sparkle install; pin `SPARKLE_BIN` to match 2.9.3; vendor modern `sign_update` next to `Sparkle-2.9.3` if desired.

---

### M2. No preflight that exported `.app` is properly signed

**Status: Resolved (May 2026).** Preflight runs `codesign --verify --deep --strict`, checks Developer ID Application, and validates team `64SX28238Z` for `macoutdated`. Use `--skip-codesign-preflight` only when debugging the script itself.

---

### M3. No `git push` or post-deploy verification

**Status: Partial (May 2026).** Default still ends after local commit with a reminder to push. Pass **`--push`** to run `git push origin HEAD` and probe the appcast URL (Pages may lag briefly).

---

### M4. `repair_appcast_structure` is fragile

**Where:** `release.sh` lines 467–538 — line-based `awk` on `<item>` / `</item>`.

**Risks:** Non-standard item formatting dropped; full appcast rewrite on every run; large git diffs.

**Suggested fix:** Prefer Sparkle `generate_appcast` for new items where possible; use repair only with backup; or use structured XML tooling.

---

### M5. `remove_existing_version_item` uses substring match on short version

**Where:** `release.sh` lines 541–562.

**Risk:** False positives if version string appears elsewhere in item XML; misses duplicates that share build only.

**Suggested fix:** Match `sparkle:version` + `sparkle:shortVersionString` together, or dedupe by enclosure URL only.

---

### M6. MacOutdated `Info.plist` Sparkle quirks

**File:** `MacOutdated/Info.plist`

| Issue | Detail |
|-------|--------|
| `SUEnableInstallerLauncherService` | `<string>true</string>` — should be boolean `<true/>` (Sparkle test app uses `<true/>`) |
| Missing keys | No `SURequireSignedFeed` or `SUVerifyUpdateBeforeExtraction` (present in Sparkle test app) |
| `SUAutomaticallyUpdate` | `true` by default — combined with settings UI in `HelpOnboardingView.swift` |

**Suggested fix:** Align plist with Sparkle 2.9 recommendations; decide if factory default should auto-download.

---

### M7. `SUPublicEDKey` not verified against `sign_update` keychain key

**Where:** `Info.plist` `SUPublicEDKey` vs signatures in appcast — no automated check in `release.sh`.

**Suggested fix:** After `sign_update`, verify signature validates against embedded public key (Sparkle docs / test update on a scratch machine).

---

### M8. Large release zips committed to git (no LFS)

**Where:** `myapps/docs/macoutdated/releases/*.zip` (~10 MB × many versions).

**Risk:** Repo bloat, slow clones, merge pain on binaries.

**Suggested fix:** Git LFS for `releases/*.zip`, or host binaries outside git with appcast URLs pointing there.

---

### M9. Startup updater may run before Sparkle is ready

**Where:** `MacOutdated/MacOutdatedApp.swift` lines 63–67 — waits ~5s then calls `checkForUpdatesInBackground()` regardless of `canCheckForUpdates`.

**Suggested fix:** Only call when `updater.canCheckForUpdates` is true; optional log if timed out.

---

## 5. Findings — Low

### L1. Script filename vs comments

File: `myapps/scripts/release.sh`. Header references `release-unified.sh`.

**Fix:** Rename or update comments.

---

### L2. `photos-export-gps-fixer` zip naming strips spaces

`SAFE_NAME` in `release.sh` removes spaces from display names. Not an issue for `macoutdated` (`MacOutdated` → `MacOutdated`).

---

### L3. `Scripts/find-macoutdated-errors.sh` (this repo)

No `set -e`; `grep` / `log show` failures don’t fail the script. Diagnostic-only.

---

### L5. Dry-run mode uses fake signature

`release.sh` `--dry-run` uses `DRY_RUN_SIGNATURE` — fine for preview.

---

### L6. Test targets embed Sparkle unnecessarily

`MacOutdatedTests` / `MacOutdatedUITests` have Embed Frameworks + Copy Files for Sparkle in `project.pbxproj`. Slows test builds only.

---

### L7. Stale doc: `Updater/` folder

`MacOutdated/Newcomer Overview.md` mentions `Updater/` + Sparkle assets; no `Updater/` folder exists (use `Sparkle-2.9.3/`).

---

### L8. `Makefile` uses `./scripts/` (lowercase)

`Makefile` lines 43, 63, 79 vs directory `Scripts/`. Works on case-insensitive APFS; fails on case-sensitive Linux CI.

---

## 6. Appcast XML — what’s correct today

From `myapps/docs/macoutdated/appcast-macoutdated.xml` (top item example):

- HTTPS enclosure URLs under `.../macoutdated/releases/`
- `sparkle:version` = build number, `sparkle:shortVersionString` = marketing version
- `sparkle:edSignature` + `length` on `<enclosure>`
- Newest item immediately after `<language>`
- `sparkle:releaseNotesLink` → `notes/{version}.html`

**Watch on each release:**

- Re-release same **short** version with new **build** — script removes by short version string (usually intended).
- Manual appcast edits bypass `repair_appcast_structure` dedupe.
- Version strings with XML-special characters (`<`, `&`) in heredoc-generated items — rare for numeric versions.

---

## 7. MacOutdated repo — Sparkle integration summary

### Entry & self-update

- `@main` → `MacOutdatedApp.swift`
- `SPUStandardUpdaterController(startingUpdater: true, ...)` 
- Background check after launch (gated off in UI tests via `ScannerViewModel.isRunningAutomatedTests`)
- Settings: `AppSettingsView` / `AppSettingsControlsView` in `HelpOnboardingView.swift`

### Scanning other apps’ Sparkle feeds (not MacOutdated’s own release)

- Feed fetch/parse: `AppScanner.swift`
- In-app update actions: `ScannerViewModel.swift`, `SparkleSupport.swift`
- Appcast viewer: `SourceViewerSupport.swift` (`sparkleAppcastViewerRequest`)

### Build settings (Release)

- `CURRENT_PROJECT_VERSION` / `MARKETING_VERSION` — keep in sync with appcast (script reads from exported `.app`, not Xcode directly).
- `ENABLE_HARDENED_RUNTIME = YES`
- `ENABLE_APP_SANDBOX = NO`
- `CODE_SIGN_STYLE = Automatic`, team `64SX28238Z`

---

## 8. Suggested release runbook (manual)

Use this checklist until `release.sh` is hardened.

### A. Build & export (MacOutdated repo)

1. Bump **Version** and **Build** in Xcode (`MARKETING_VERSION` / `CURRENT_PROJECT_VERSION`).
2. **Product → Archive** → **Distribute App** → Developer ID, export `.app`.
3. Verify signature:
   ```bash
   codesign --verify --deep --strict "/path/to/MacOutdated.app"
   codesign -dv --verbose=4 "/path/to/MacOutdated.app"
   ```
4. Notarize & staple (recommended):
   ```bash
   # zip for notarytool, or submit .app per your usual flow
   xcrun notarytool submit ... --wait
   xcrun stapler staple "/path/to/MacOutdated.app"
   ```

### B. Publish (myapps repo)

5. Ensure `SPARKLE_BIN` points at Sparkle 2.9.x tools with EdDSA `sign_update`.
6. Run:
   ```bash
   ./scripts/release.sh macoutdated "/path/to/MacOutdated.app"
   ```
7. Review generated:
   - `docs/macoutdated/releases/MacOutdated-{version}.zip`
   - `docs/macoutdated/notes/{version}.html`
   - `docs/macoutdated/appcast-macoutdated.xml`
8. Confirm `minimumSystemVersion` matches policy (see **H2**).
9. Commit succeeded (if not, fix manually — see **H3**).
10. Push:
    ```bash
    git push origin main
    ```
11. Verify live feed:
    ```bash
    curl -fsS "https://rphoto.github.io/myapps/macoutdated/appcast-macoutdated.xml" | head -30
    ```

### C. Smoke test

12. Install current public build; trigger **Check for Updates** (or wait for background check).
13. Confirm update offers correct version and installs.

---

## 9. Suggested fixes — priority order

| Priority | Item | Where to change | Status |
|----------|------|-----------------|--------|
| 1 | Add notarization + codesign verify before zip/sign | `myapps/scripts/release.sh` + runbook | Open (manual / `--require-notarized`) |
| 2 | Align `minimumSystemVersion` with deployment target | `release.sh` + appcast | **Done** (15.0) |
| 3 | Harden git end (fail loud, remind `git push`) | `release.sh` | **Done** (`--push` optional) |
| 4 | Verify Release `.app` Sparkle layout (`Updater.app`) | `MacOutdated.xcodeproj` Copy Files | Open |
| 5 | Fix Sparkle keys in `Info.plist` | `MacOutdated/Info.plist` | Open |
| 6 | Pin/document `SPARKLE_BIN` for Sparkle 2.9.3 | `release.sh`, README in `myapps` | Open |
| 7 | Gate background update on `canCheckForUpdates` | `MacOutdatedApp.swift` | Open |
| 8 | Consider Git LFS for release zips | `myapps/.gitattributes` | Open |
| 9 | Update `Newcomer Overview.md` | This repo | **Done** |

---

## 10. Related paths (quick reference)

### This repo (MacOutdated)

```
MacOutdated/Info.plist
MacOutdated/MacOutdatedApp.swift
MacOutdated/HelpOnboardingView.swift
MacOutdated/SparkleSupport.swift
MacOutdated/AppScanner.swift
MacOutdated.xcodeproj/project.pbxproj
Sparkle-2.9.3/
Scripts/find-macoutdated-errors.sh
```

### myapps repo

```
myapps/scripts/release.sh
myapps/docs/macoutdated/appcast-macoutdated.xml
myapps/docs/macoutdated/releases/
myapps/docs/macoutdated/notes/
```

---

## 11. What changed vs initial review (before `myapps` was included)

| Initial concern | Status |
|-----------------|--------|
| No release pipeline | **Resolved** — `myapps/scripts/release.sh` |
| Appcast only external | **Resolved** — canonical copy in `myapps/docs/macoutdated/` |
| Version drift | Re-check each release (see §1) |
| No notarization | **Still open** |
| Updater Copy Files embed | **Still open** (MacOutdated Xcode) |
| Plist / startup updater quirks | **Still open** |
| Appcast min OS vs deployment target | **Resolved** — 15.0 aligned (May 2026) |
| Git/release script footguns | **Resolved** — require git, commit recovery, optional `--push` |
| Codesign preflight | **Resolved** — default verify before zip |

---

*This document is maintainer-facing only. Update it when the release process or Sparkle integration changes.*
