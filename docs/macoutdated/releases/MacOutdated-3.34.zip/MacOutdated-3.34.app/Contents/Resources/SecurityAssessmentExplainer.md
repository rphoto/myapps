# MacOutdated Security Explainer

This guide explains the security findings MacOutdated surfaces, what they usually mean in practice, how worried most people should be, and why a legitimate app may still show the finding.

## Code Signing

### What does this mean?

Code signing proves that an app was signed by a particular identity and has not been changed since it was signed. If MacOutdated says the signature is invalid, ad-hoc, or missing, macOS has much less assurance about who produced the app and whether it was altered.

### How worried should I be?

High if the app is unsigned, ad-hoc signed, or has an invalid signature. Those cases deserve real scrutiny unless the app is a local development build you created yourself.

### Why would a developer have this issue?

Common reasons include developer builds, packaging mistakes, damaged downloads, manual modification after signing, or outdated distribution pipelines.

## Gatekeeper

### What does this mean?

Gatekeeper is macOS policy enforcement for downloaded software. A rejection such as "signed by the developer, but not notarized by Apple" usually means the app has a valid developer signature but Apple has not notarized it for normal Gatekeeper approval.

### How worried should I be?

Medium. It is more serious than a normal advisory, but it does not automatically mean the app is malicious. It often means the app is signed correctly but skipped Apple's notarization step.

### Why would a developer have this issue?

Older apps, internal tools, niche utilities, and manually distributed software often miss notarization. Some apps still run without a warning because quarantine was removed, the user already allowed them once, or they were copied locally rather than launched as a fresh download.

## Hardened Runtime

### What does this mean?

Hardened Runtime is a macOS protection set that blocks several classes of runtime tampering and code injection. Most modern Developer ID apps should have it enabled.

### How worried should I be?

Medium if it is missing on modern third-party software. It is an important protection, but older or unusual apps may still work fine without it.

### Why would a developer have this issue?

Legacy build systems, old apps that predate current notarization practices, or compatibility problems with plug-ins, debuggers, scripting, or custom runtime behavior can all lead to Hardened Runtime being left off.

## App Sandbox

### What does this mean?

App Sandbox restricts what an app can access on your Mac. Many Mac App Store apps use it. Many direct-download professional apps do not.

### How worried should I be?

Usually low by itself. A missing sandbox is common for non-App-Store Mac software, especially tools that need broad file access, scripting, device access, or plug-in loading.

### Why would a developer have this issue?

Direct-download apps often need capabilities the sandbox makes awkward or impossible, such as broad filesystem access, automation, developer tooling, hardware integration, or third-party extensions.

## Team ID

### What does this mean?

The Team ID identifies the Apple developer account that signed the app. It is useful for comparing multiple apps from the same vendor and for spotting unexpected signer changes.

### How worried should I be?

Low by itself. It is mainly attribution information, not a problem indicator.

### Why would a developer have this issue?

Every properly signed Developer ID app should have one. If it is missing, the app may be ad-hoc signed or not signed with a normal Apple developer identity.

## Signed By

### What does this mean?

This shows the human-readable certificate name for the signer. It tells you who macOS believes signed the app.

### How worried should I be?

Low by itself. It becomes useful when it changes unexpectedly or does not match the vendor you thought you installed.

### Why would a developer have this issue?

It normally reflects the developer or company certificate name. A different signer may be legitimate after an acquisition, account migration, or distribution change, but it is worth verifying.

## Library Validation

### What does this mean?

Library Validation is part of Hardened Runtime. When it is enabled, the app is more restricted about what dynamic libraries and plug-ins it can load. If it is disabled, the app can load a broader range of external code.

### How worried should I be?

Usually low to medium by itself. This is a real reduction in protection, but it is also common in legitimate apps with extension or plug-in architectures. It should be treated as an advisory, not as proof the app is compromised.

### Why would a developer have this issue?

Browsers, media tools, developer tools, automation utilities, audio software, and pro apps often need to load plug-ins, helper components, or third-party frameworks that do not fit strict library-validation rules.

## Unsigned Executable Memory

### What does this mean?

This usually indicates a JIT-style entitlement that allows writable and executable memory at runtime. That is often needed for JavaScript engines, browser components, emulators, virtualization, or other dynamic execution features.

### How worried should I be?

Medium by itself. It weakens an important mitigation, but many mainstream apps legitimately need it. It becomes more concerning when combined with other problems such as broken signing or disabled protections across the board.

### Why would a developer have this issue?

Electron apps, browsers, scripting engines, media tools, and some creative software commonly need JIT or similar runtime code generation.

## Certificate

### What does this mean?

An expired code-signing certificate means the signing certificate is no longer current. Depending on timestamps and validation context, the app may still be valid for software that was signed while the certificate was active, but it is still worth noting.

### How worried should I be?

Medium to high depending on context. It is more serious than a normal advisory and deserves follow-up, especially for newly distributed software.

### Why would a developer have this issue?

Old releases, abandoned apps, or sloppy release processes can leave apps signed with expired certificates.

## Bundle ID

### What does this mean?

MacOutdated flags a problem when an app claims an Apple-style bundle identifier such as `com.apple.*` but is not actually signed by Apple. That is a strong mismatch between identity and signature.

### How worried should I be?

High. This is unusual and deserves immediate scrutiny.

### Why would a developer have this issue?

Normally they should not. This is more often a packaging mistake, a copied bundle identifier, or something intentionally misleading.

## Notarization

### What does this mean?

Notarization is Apple's automated malware scan for software distributed outside the Mac App Store. When a Developer ID app passes, Apple issues a ticket that is normally stapled into the app bundle. MacOutdated flags "Not notarized by Apple" when an app has a valid Developer ID signature but no notarization ticket. This is exactly the state that makes Gatekeeper refuse to launch a freshly downloaded app and instead offer to move it to the Trash.

### How worried should I be?

Medium. The signature is intact, so the app has a real, verifiable developer identity — it simply skipped or predates Apple's notarization step. It is not proof of anything malicious, but Apple never ran its malware scan against this build, so an unrecognized vendor deserves more scrutiny than a notarized one.

### Why would a developer have this issue?

Older apps, internal or niche tools, and manually distributed software often miss notarization. Because MacOutdated checks offline, an app that was notarized but never had its ticket stapled to the bundle can also show here; the Gatekeeper row in the app's details reflects the authoritative live check for those cases.

## Quarantine

### What does this mean?

Quarantine means macOS marked the app as downloaded from the internet. This is not a problem by itself. It is simply the flag that causes first-run checks and warnings.

### How worried should I be?

Usually low. In many cases it is useful, because it means Gatekeeper still has the context it expects for downloaded software.

### Why would a developer have this issue?

They usually do not control it directly. Browsers, Mail, AirDrop, and other transfer paths often set quarantine automatically.

## System Integrity Protection Disabled

### What does this mean?

System Integrity Protection (SIP) is a macOS security policy that prevents modification of protected system files, directories, and processes — even by root. MacOutdated reports this when `csrutil status` indicates SIP is not fully enabled.

### How worried should I be?

High. SIP off dramatically lowers the bar for persistent, privileged attacks. It should only be disabled temporarily for specific developer tasks and re-enabled immediately after.

### Why would someone have this issue?

Some kernel extension workflows and certain older developer tools require SIP to be partially or fully disabled. In normal use it should always be on.

## Broad NOPASSWD sudo Rule

### What does this mean?

MacOutdated found a sudoers rule that allows commands to run with `sudo` without prompting for a password, and the rule appears broad enough to grant wide administrative access.

### How worried should I be?

High if you did not intentionally configure it. Passwordless admin rules are convenient for automation, but they also remove an important privilege-escalation barrier.

### Why would someone have this issue?

Developers, local automation setups, lab Macs, and some management tools sometimes add `NOPASSWD` rules on purpose. The concern is unexpected rules, stale fragments, or policy files with weak ownership and permissions.

## Shell Startup Persistence

### What does this mean?

MacOutdated found a suspicious command in a shell startup file such as `~/.zshrc`, `~/.zprofile`, `~/.bash_profile`, or a system-wide shell profile. Examples include remote bootstrap pipes, `launchctl` persistence commands, or `DYLD_*` exports.

### How worried should I be?

Medium to high depending on the command. A benign developer environment can legitimately customize these files, but hidden relaunch logic, remote install pipes, and DYLD injection exports deserve real scrutiny.

### Why would someone have this issue?

Installers, development tools, shell frameworks, and malware all modify shell startup files. The difference is whether the command is expected, recognized, and proportional to what the tool claims to do.

## Gatekeeper Disabled

### What does this mean?

Gatekeeper is disabled system-wide. MacOutdated reports this when `spctl --status` shows assessments are disabled rather than enabled.

### How worried should I be?

High. With Gatekeeper disabled, macOS will not check the code signature or notarization status of any downloaded app before running it, removing a key first line of defense against malicious software.

### Why would someone have this issue?

Developers sometimes disable Gatekeeper to run unsigned tools or test builds. It should be re-enabled immediately after any such task.

## FileVault Disabled

### What does this mean?

The disk is not encrypted with FileVault. Anyone with physical access to this Mac can boot from an external volume and read all files without knowing the account password.

### How worried should I be?

Medium to high, depending on how sensitive your data is and your physical security situation. For laptops especially, FileVault is strongly recommended.

### Why would someone have this issue?

FileVault may have been turned off intentionally on a desktop that is never taken out of a secured location, or it may simply never have been enabled.

## Application Firewall Disabled

### What does this mean?

The macOS Application Firewall is not active. It normally blocks unsolicited inbound connections to apps and services that are not configured to accept them.

### How worried should I be?

Low to medium. Many Macs have this off without any immediate impact, but enabling it adds an extra layer of protection against inbound probing.

### Why would someone have this issue?

The firewall is off by default on macOS and must be explicitly enabled in System Settings. Some users or administrators turn it off to troubleshoot connectivity.

## SSH Authorized Keys

### What does this mean?

An entry in `~/.ssh/authorized_keys` or `/var/root/.ssh/authorized_keys` grants the holder of the matching private key password-free SSH access to this Mac.

### How worried should I be?

High for root-level keys, which give complete system control to whoever holds the private key. Medium for user-level keys, which allow remote login as that user without a password. Any unrecognized key deserves immediate removal.

### Why would someone have this issue?

Developers and administrators legitimately use authorized keys for scripted or remote access. The concern is keys added without your knowledge, or keys from an old access relationship that was never cleaned up.

## Privacy and Permission Grants (TCC)

### What does this mean?

macOS maintains a database of which apps have been granted access to sensitive resources such as Full Disk Access, Screen Recording, Camera, Microphone, and Input Monitoring. MacOutdated reads these databases and summarizes what is currently approved.

### How worried should I be?

Usually low to medium depending on what is listed. Seeing familiar apps like backup tools, communication apps, or security software in this list is expected. The concern is apps you do not recognize or that have more access than their function requires.

High-privilege grants to watch for:
- Full Disk Access: the app can read any file on your Mac
- Screen Recording: the app can capture everything on your screen
- Input Monitoring: the app can log every keystroke you type

Other common permission types you may see:
- Accessibility: the app can observe and control parts of other apps' interfaces
- Automation: the app can send Apple Events to control other apps
- Camera and Microphone: the app can capture audio/video input
- Contacts, Calendar, and Photos: the app can read personal data from those stores
- System Admin Files: the app can read sensitive administrative files

### Why would an app have this?

Backup software needs Full Disk Access. Video conferencing needs Camera and Microphone. Window managers and accessibility tools need Accessibility. Some entries may also be orphaned grants, where the app was removed but its old permission record still remains in the TCC database. Many of these are completely legitimate. The value of this section is recognizing what you have approved and noticing anything unexpected.

When MacOutdated flags an orphaned permission grant, treat confidence as stronger when the bundle identifier was previously seen on this Mac and is now no longer installed. If the identifier was never observed as an installed app, review more carefully before removing the grant.

## System Extensions

### What does this mean?

System extensions are privileged components installed outside the normal app bundle, often for networking, endpoint security, device drivers, or VPN features. MacOutdated now shows the host app when it can find one, plus code signing and signer details for the installed extension itself.

### How worried should I be?

Usually low if the extension is signed, the signer matches the vendor you expect, and there is a matching host app installed. It deserves more scrutiny if the extension is unsigned, ad-hoc signed, has a broken signature, or no corresponding app can be found.

### Why would a developer have this issue?

VPNs, security tools, device utilities, and some enterprise products commonly install system extensions. A missing host app often means the app was removed but the extension was left behind, or the software was installed in an unusual location.

## Launch Target Missing

### What does this mean?

A background item such as a launch agent, daemon, login item, or helper points to an executable path that no longer exists on disk. The registration is still present, but the program it is supposed to launch is missing.

### How worried should I be?

Usually medium. This often indicates broken leftovers from an uninstall, a failed update, or manual file removal rather than malware by itself, but it does mean macOS is carrying a stale background-item entry.

### Why would a developer have this issue?

Common causes include incomplete uninstallers, renamed app bundles, moved helper tools, or installers that forgot to remove old launchd plists and helper registrations.

## Writable Launch Target

### What does this mean?

MacOutdated found a launchd job whose executable target is group-writable or world-writable. That means a persistent launchd registration points at a file that another user or process may be able to replace or modify.

### How worried should I be?

High. A writable persistent executable is a strong security smell because it can let an attacker hijack an already-registered background job.

### Why would a developer have this issue?

Usually because of sloppy installer permissions, extracted archives that preserved bad mode bits, or scripts copied into place without tightening ownership and permissions afterward.

## Launch Target Not Resolved

### What does this mean?

MacOutdated found a background item definition, but could not determine a concrete executable path from it. That usually means the item uses an unusual launch configuration, indirect command structure, or incomplete metadata.

### How worried should I be?

Usually low to medium. It is worth inspecting, but this is often an analysis limitation or a nonstandard launchd configuration rather than evidence of compromise.

### Why would a developer have this issue?

Some launchd jobs build command lines dynamically, rely on wrapper scripts, or use plist structures that do not map cleanly to a single executable path.

## System Launch Job Targets User-controlled Path

### What does this mean?

MacOutdated found a system-level launch agent or daemon in `/Library` whose executable target points into the current user's home directory. That creates a privileged or semi-privileged persistence point backed by a user-controlled path.

### How worried should I be?

High. System launch jobs should not normally depend on files under a user's home directory.

### Why would a developer have this issue?

Usually they should not. This tends to indicate a packaging mistake, a broken migration, or a risky custom deployment approach rather than a well-structured macOS installer.

## Shadow Binary

### What does this mean?

MacOutdated found a launch target executable running from `~/Library/Application Support/` that is not inside a normal `.app` bundle. That means a background item is launching a standalone binary from an app-support data area rather than from a clearly packaged macOS app.

### How worried should I be?

Medium to high depending on context. Some legitimate software uses helper binaries in Application Support, but this layout deserves closer scrutiny because it is also a common place for opaque updater helpers, remnants of old installs, or harder-to-identify background executables.

### Why would a developer have this issue?

Some apps ship command-line helpers, updater tools, or agent binaries into Application Support instead of a bundled `.app` or framework location. It can also happen when uninstallers leave behind launch agents that still point to old support-folder binaries.

## Browser-Managed Extensions

### What does this mean?

Some browser extensions shown on the Background Items page are managed by the browser itself rather than exposed as standalone signed app bundles. In those cases, MacOutdated may show that code signing was not assessed because the browser owns the extension loading model.

### How worried should I be?

Usually low by itself. The more important question is whether you recognize the extension and intended to install it.

### Why would a developer have this issue?

Chromium-family browsers and similar platforms often package extensions as browser-managed components with metadata and scripts, not as normal macOS apps with separate code-signing checks.

## Legacy Safari Extensions

### What does this mean?

This indicates an older Safari extension package model rather than a modern app extension. Legacy Safari extensions predate current extension packaging and security expectations.

### How worried should I be?

Usually medium. A legacy extension is not automatically unsafe, but older extension formats deserve more scrutiny because they come from an older security model and may no longer be actively maintained.

### Why would a developer have this issue?

The developer may never have migrated the extension to Safari App Extensions, or the extension may simply be an older package that remains installed from a much earlier Safari era.

## Insecure Sparkle Update Feed

### What does this mean?

An app that uses the Sparkle auto-update framework has its update feed URL set to `http://` instead of `https://`. Update checks over plain HTTP can be intercepted and tampered with on the network.

### How worried should I be?

Medium. This is a real security gap — on an untrusted network, an attacker could intercept the update check and serve a malicious app update that the Sparkle framework would then install. The risk is higher if you often use public or shared networks.

### Why would a developer have this issue?

This is a legacy configuration from an era when HTTPS was not the default. Most modern Sparkle integrations use HTTPS, but older or unmaintained apps may still have HTTP feed URLs that were never updated.

## Known CVE in Homebrew Package

### What does this mean?

MacOutdated checked the installed version of an outdated Homebrew package against the OSV.dev vulnerability database and found a known CVE (Common Vulnerabilities and Exposures) entry affecting that version.

### How worried should I be?

Medium to high, depending on the CVE. A CVE means the vulnerability is publicly documented and may have working exploits available. Packages that expose a network service or handle untrusted data are higher priority to update.

### Why would this happen?

This is expected behavior for outdated software. CVEs accumulate over time in any actively used package. The finding is simply a prompt to prioritize updating that particular package, especially if the CVE severity or description matches the way you use that tool.
