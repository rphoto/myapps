# Utility Tools Help

This help page covers the four utility windows MacOutdated currently exposes outside the main navigation.

- **Backup Duplicate Inspector**
- **Log Maintenance**
- **AI Input Inspector**
- **CloudKit Environment Bridge**

# Backup Duplicate Inspector

This tool inspects stored backup snapshot records and groups duplicates by machine identity and content hash.

Use it to:

- review duplicate CloudKit backup records
- see the generated duplicate report
- delete older duplicate records while keeping the newest record in each duplicate group

This is a maintenance tool for backup metadata, not for deleting Homebrew packages or local files.

# Log Maintenance

This tool is for reviewing and pruning Activity Log history.

Use it to:

- filter log history by Mac hostname
- review success and failure trends over time
- search log entries
- permanently delete selected log records from local storage and iCloud

Expand **Advanced** to import or export selected entries as JSON. JSON import replaces or merges records you choose; export is useful for backups or support. Treat both as advanced operations.

Deleting entries here is destructive and cannot be undone.

# AI Input Inspector

This tool shows the compressed input MacOutdated generated for Apple Intelligence summary requests.

Use it to:

- inspect the exact lines prepared for summarization
- search within that generated input
- compare initial chunk boundaries with the final segment split when context limits force re-chunking
- copy the full generated input for troubleshooting

This window is diagnostic only. It does not send anything itself.

# CloudKit Environment Bridge

This tool moves selected CloudKit zone data between builds that point at different CloudKit environments.

Use it to:

- export selected zones from the current build
- save that export bundle locally
- open another build and replace matching zones there from the saved bundle

It currently supports:

- **Activity Log**
- **App Info**
- **Backup Snapshots**
- **Background Items**
- **Security Scan**
- **Historical Apps**

Replacing zones deletes the selected destination-zone contents first, then writes the saved bundle data. Treat it as an advanced migration and testing tool.

# Best Practice

- Use these tools only when the normal page workflow is not enough.
- Read the confirmation text carefully before deleting or replacing anything.
- Prefer export, copy, or inspection first when you are diagnosing a problem.
- Treat CloudKit and log maintenance operations as advanced actions.
