# Security Scan Coverage Gap Plan (Internal)

This document tracks security-scan coverage gaps identified from the current Security Scan implementation.

Scope note: internal planning only. Do not surface this document in the MacOutdated UI.

## Current Round Status (July 2026)

This round implements the following on the existing (fast) Security Scan page. No Deep Security Scan page yet.

Implementing now:

- Remote Access Posture: Remote Login (SSH), Screen Sharing, Remote Management/ARD, Remote Apple Events via `launchctl print-disabled system` (fail-open on timeout).
- Network Listeners: `lsof -iTCP -sTCP:LISTEN` inventory; advisory only for wildcard binds by non-Apple processes.
- `/etc/hosts` drift: non-default entries informational; redirects/blackholes of Apple update or security-vendor domains advisory.
- Custom Root Certificates: `security dump-trust-settings -d` (admin domain); custom trusted roots advisory, SSL always-trust concern.
- `at` job coverage: `/var/at/jobs` plus atrun enablement state.
- Browser Extensions & Policies: Safari (pluginkit), Chrome-family manifests, Firefox `extensions.json`, Chrome enterprise policy detection. Entire section gated off during automated tests.

Severity policy for all new sections: default informational; advisory only for explicitly risky patterns; concern reserved for SSL always-trust custom roots. This is deliberately conservative to avoid re-creating false-positive noise.

Also in this round (not new coverage, but noise reduction):

- False-positive fixes: stock macOS sudoers rules (`root`/`%admin`/`%wheel ALL=(ALL) ALL`) no longer flagged; `nohup` indicator requires actual backgrounding; launch-target parse failures downgraded to informational; validly signed shadow binaries downgraded; cron entries risk-tiered instead of blanket advisory; user `authorized_keys` informational (root stays concern); TCC vendor matching by bundle-ID prefix/exact signer instead of substring; installed + validly signed TCC clients capped at medium; unsigned Homebrew-cask apps downgraded to advisory; subprocess timeouts read as indeterminate instead of "bad" (Gatekeeper assess, deep verify, per-app spctl); unstapled-but-possibly-notarized Developer ID apps informational; system extensions with a missing host app no longer forced to advisory when validly signed.
- Persistent per-finding "Mark as Expected" (ignore) mechanism with stable fingerprints, an Ignored group per section, and cross-Mac roaming via settings sync.

Deferred (unchanged below): Deep Security Scan page/IA, keychain ACL audit, configuration-profile payload analysis, SSH hardening/config drift checks, fleet notarization verification, proxy/DNS drift (hosts file only for now), periodic-script allowlist rework.

## Goals

- Keep frequent scans fast enough for routine use.
- Avoid overwhelming users with noisy or low-actionability findings.
- Split advanced or slow checks into a separate Deep Security Scan flow.

## Proposed Product Split

- Fast Security Scan page target runtime: 10 to 30 seconds on typical Macs.
- Deep Security Scan page target runtime: 1 to 5 minutes, clearly labeled as advanced and optional.
- Fast page should prioritize high-signal and actionable findings.
- Deep page can include richer inventory, correlation, and slower probing.

## Current High-Value Gaps

1. Network exposure checks are missing
- No scan for listening ports plus owning process and binary.
- No checks for remote access exposure posture (for example: Remote Login/SSH, Remote Management/ARD, Screen Sharing, AirDrop).
- No proxy, DNS resolver, or `/etc/hosts` tampering checks.

2. Persistence coverage is strong but not complete
- Current coverage includes launchd, shell startup, cron, periodic scripts, emond, and login hooks.
- `at` job coverage added this round (`at Jobs` section). Additional less-common persistence surfaces still open.

3. Trust-store and credential abuse checks are missing
- No scan for unexpected root/intermediate certificates in system or user keychains.
- No checks for suspicious keychain ACL/trusted-app access entries.
- No SSH hardening checks beyond `authorized_keys` presence (for example risky file modes and sshd configuration drift).

4. System security posture is partial
- Current checks include SIP, Gatekeeper, FileVault, and firewall state.
- Missing stealth mode, automatic security update posture, Lockdown Mode status, and deeper firewall posture checks.

5. App and update trust-chain checks can be expanded
- Current checks include app signing/hardening findings and insecure Sparkle HTTP feed URLs.
- Missing fleet-level notarization verification, quarantine anomaly checks, and broader updater trust-chain checks beyond Sparkle URL scheme.

6. Configuration profile analysis is shallow
- Current coverage detects MDM enrollment and lists installed profiles.
- Missing payload-level risk analysis (proxy payloads, root certificate payloads, restrictions, VPN/content filter/network extension payloads, signature/trust indicators).

7. Browser security surface is missing
- No extension inventory and permission-risk scan for Safari, Chrome, and Firefox.
- No detection of forced enterprise policies that modify homepage/search/proxy settings.

8. Legacy kernel extension visibility is missing
- Current coverage includes System Extensions.
- Missing checks for legacy kernel extensions (`kext`) present or loaded where relevant.

## Implementation Checklist

### A. Fast Security Scan candidates (high-signal, low-latency)

1. Network exposure posture (metadata only)
- [x] Add section: `Network Listeners` (this round).
- [x] Enumerate listening sockets and owners (avoid deep packet/process tracing).
- [x] Flag wildcard-bind listeners from non-Apple processes as advisory.
- [x] Include checked summary count and top categories only.
- [x] Runtime budget: 2 to 6 seconds.

2. Remote access and sharing posture
- [x] Add section: `Remote Access Posture` (this round).
- [x] Check Remote Login (SSH), Screen Sharing, Remote Management/ARD states.
- [x] Flag enabled services as advisory by default.
- [x] Runtime budget: under 2 seconds.

3. Proxy/DNS/hosts drift
- [ ] Add section: `Network Configuration Drift` (proxy/DNS deferred).
- [ ] Check system proxy settings and active network service proxies.
- [x] Check suspicious `/etc/hosts` entries (this round; DNS resolver overrides deferred).
- [x] Runtime budget: 1 to 3 seconds.

4. SSH hardening quick checks
- [ ] Extend existing SSH area with `permissions and config posture` findings.
- [ ] Validate ownership/permissions for `~/.ssh`, `authorized_keys`, private keys.
- [ ] Parse high-risk `sshd_config` settings where readable.
- [ ] Runtime budget: under 1 second.

5. System posture expansion (quick)
- [ ] Extend existing `System Security Posture` section.
- [ ] Add stealth mode, software update auto-security posture, and related toggles.
- [ ] Keep findings succinct and actionable.
- [ ] Runtime budget: under 1 second.

### B. Deep Security Scan candidates (slower or more complex interpretation)

1. Browser extension and policy risk inventory
- [x] Implemented on the fast page this round as `Browser Extensions & Policies` (gated during automated tests).
- [x] Inventory Safari/Chrome-family/Firefox extensions with broad permissions.
- [x] Detect Chrome enterprise policy overrides (`ExtensionInstallForcelist`, proxy keys).
- [x] Runtime budget: a few seconds (file reads + pluginkit; no per-extension probing).

2. Trust-store anomaly detection
- [x] Implemented on the fast page this round as `Custom Root Certificates` (admin trust domain via `dump-trust-settings -d`).
- [ ] User-keychain enumeration and recent-addition correlation deferred.
- [x] Flag unusual trust settings (SSL always-trust = concern).
- [x] Runtime budget: under 10 seconds.

3. Keychain ACL/trusted-app audit
- [ ] Add deep section: `Keychain Access Surface`.
- [ ] Flag broad trusted-app access where interpretation is reliable.
- [ ] Gate to reduce false positives and avoid noisy output.
- [ ] Runtime budget: 20 to 60 seconds.

4. Configuration profile payload-level analysis
- [ ] Extend current profile section in deep mode.
- [ ] Parse payload types: proxy, cert trust, VPN, content filter, network extension, restrictions.
- [ ] Risk-score payload combinations and unknown issuers.
- [ ] Runtime budget: 5 to 20 seconds.

5. App trust-chain deep checks
- [ ] Add deep section: `Notarization & Quarantine Anomalies`.
- [ ] Verify notarization status for a selected app subset.
- [ ] Detect suspicious quarantine drift patterns.
- [ ] Runtime budget: 30 to 180 seconds depending on sample size.

6. Legacy kernel extension visibility
- [ ] Add deep section: `Legacy Kernel Extensions`.
- [ ] Inventory present/loaded kexts and correlate with vendor/signing metadata.
- [ ] Runtime budget: 3 to 10 seconds.

## Phase Plan

### Phase 1 (Fast page, immediate value)
- [ ] Network exposure posture
- [ ] Remote access posture
- [ ] Proxy/DNS/hosts drift
- [ ] SSH hardening quick checks
- [ ] System posture quick expansion

Exit criteria:
- Typical run remains under 30 seconds.
- Findings remain concise and understandable in current UI.

### Phase 2 (Deep page foundation)
- [ ] Add Deep Security Scan page shell and navigation entry.
- [ ] Add explicit runtime warning and optional execution.
- [ ] Add extension/policy and trust-store sections first.

Exit criteria:
- Deep scan runs independently of fast scan.
- Users can run fast scan frequently without long waits.

### Phase 3 (Deep expansion)
- [ ] Add keychain ACL, profile payload, app trust-chain deep checks, and legacy kext checks.
- [ ] Add better grouping and filtering controls for high-volume deep findings.

Exit criteria:
- Deep findings are grouped by category and risk.
- False-positive rate is manageable.

## Data Source Notes (Initial)

- Prefer in-process APIs where possible.
- Use subprocesses only when no practical API exists.
- Keep expensive commands off the fast path.
- Reuse existing risk mapping (`SecurityRiskRating`) and level mapping (`SecurityFindingLevel`).

## Test And UX Guardrails

- Use `ScannerViewModel.isRunningAutomatedTests` gating for scans that could trigger prompts or machine-wide access.
- Keep fast scan deterministic and side-effect-light.
- Deep scan must be explicit opt-in and clearly marked as longer-running.
- Ensure every new section has an honest `checkedSummary` with counts and scan limitations.

## Proposed Information Architecture (Deep Security Scan)

### Navigation and Placement

- Add a separate top-level destination: `Deep Security Scan`.
- Keep current `Security Scan` as the default frequent-use page.
- Add a short descriptor under the deep page title: `Advanced checks. Longer runtime.`

### Page Layout

1. Header band
- Status line, last run timestamp, and runtime estimate.
- Primary button: `Run Deep Scan`.
- Secondary button: `Run Selected Checks`.
- Optional stop button while scan is active.

2. Scope selector (pre-run)
- Check groups with per-group runtime hints.
- Presets:
- `Recommended` (high-signal deep checks only)
- `Full Deep Scan` (all deep checks)
- `Custom`

3. Result controls row
- Search box.
- Risk filter: `All`, `Concern`, `Advisory`, `Informational`.
- Category filter (multi-select).
- Source filter: `Fast-compatible`, `Deep-only`.
- Toggle: `Show actionable only`.

4. Results body
- Section cards similar to existing `SecurityScanSectionView` for visual consistency.
- Default collapsed state for high-volume sections.
- Each section shows:
- checked count
- runtime for that section
- finding count by severity
- confidence/noise hint where needed

5. Detail side panel or sheet
- Raw evidence snippet.
- Why this matters text.
- Suggested user action.
- Safe copy/export action.

### Proposed Deep Sections (Initial)

- Browser Extensions and Managed Policies
- Certificate Trust Anomalies
- Keychain Access Surface
- Configuration Profile Payload Risk
- Notarization and Quarantine Anomalies
- Legacy Kernel Extensions

### Default Expansion Rules

- Auto-expand sections containing `concern` findings.
- Keep advisory/informational-heavy sections collapsed by default.
- When `Show actionable only` is on, hide purely informational groups.

### Runtime and UX Strategy

- Do not run deep checks automatically on page open.
- Persist last selected scope preset.
- Show per-section progress and permit partial completion display.
- If a section exceeds timeout budget, mark as `incomplete` and continue others.

### Data and Model Reuse

- Reuse `SecurityScanFinding` and `SecurityScanSection` as baseline models.
- Add optional metadata fields only if needed for deep UX:
- `scanTier` (`fast`, `deep`)
- `evidenceKind` (`config`, `process`, `filesystem`, `policy`)
- `actionability` (`actionable`, `review`)
- Avoid breaking existing fast scan rendering paths.

### Reporting and Export

- Export supports `Fast only`, `Deep only`, and `Combined` modes.
- Include section runtime and completion status in reports.
- Include explicit caveats for unavailable checks or permission-gated checks.

### Guardrails

- Deep checks remain explicit opt-in.
- No privileged writes or invasive remediation from deep page by default.
- Respect automated test gating and avoid prompt-triggering work in tests.

### UI Consistency Requirements (Fast and Deep)

- Preserve existing color semantics:
- green for good/current/success
- orange for warning/advisory/medium risk
- red for concern/high risk/destructive/failed
- blue or secondary for informational/neutral
- Use severity/risk pills consistent with existing Security Scan visual language.
- Keep section-level expand/collapse behavior aligned with existing page patterns.
- Provide `Expand All` and `Collapse All` behavior on deep page when results are present.
- Preserve searchable/filterable findings behavior consistent with current UX.
- Keep selection model consistent for deletable findings:
- select all/deselect all affordances
- bulk `Delete Selected` flow with confirmation
- no delete affordance for non-deletable findings
- Reuse existing grouped-card presentation and checked-summary style where practical.

## Working Rules For This Plan

- Keep implementation changes localized to Security Scan files unless required.
- Gate privacy-sensitive or machine-global work during automated tests.
- Reuse existing section and finding models (`SecurityScanSection`, `SecurityScanFinding`) and color semantics.
- Prefer additive sections over behavior changes in existing sections unless necessary.
- Track each new scanner item with explicit checked summary text for report clarity.
