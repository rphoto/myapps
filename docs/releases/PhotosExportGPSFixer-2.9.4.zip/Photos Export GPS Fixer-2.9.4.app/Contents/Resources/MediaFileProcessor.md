//
//  MediaFileProcessor.md
//  
//
//  Created by User on 2025-08-04.
//

/**
 # MediaFileProcessor

 The `MediaFileProcessor` module provides tools to extract and update GPS metadata and related device information from supported media files (currently `.dng`, `.heic`, `.tif`, `.jpeg`) and their associated XMP sidecar files. It requires that the XMP sidecar files already exist; it will never create new XMP files from scratch. The processor supports advanced handling of metadata synchronization, including conditional updates based on GPS tolerance, device information checks, and configurable skip/overwrite logic, which can be essential in professional photo workflows.

 ## Main Types

 - `GPSData` – Represents GPS coordinates including latitude, longitude, and their references (N/S, E/W).
 - `GPSDifference` – Represents differences between two GPS data points, useful for tolerance checks.
 - `DeviceData` – Contains device-specific metadata such as device model, make, and other relevant data extracted from media files.
 - `MediaData` – Aggregates GPSData and DeviceData for a given media file.
 - `ProcessingResultDetail` – Additional detail objects used within processing results.
 - `ProcessingResult` – Enum representing the result of processing a file and its XMP, with cases:
    - `.updated(changes: [String])` – The XMP file was updated; changes describe what was written.
    - `.alreadyCorrect` – The XMP file already contained the correct metadata; no update was needed.
    - `.withinTolerance(differences: [String])` – The GPS differences were within acceptable tolerance; no update done.
    - `.fileNotFound(reason: String)` – The media file or its expected XMP sidecar was missing.
    - `.unsupportedFile(reason: String)` – The media file format is not supported.
    - `.skippedMissing(reason: String)` – Skipped processing due to missing metadata or files.
    - `.skippedNonApple(device: DeviceData?, reason: String)` – Skipped because the device is non-Apple and the processor is configured to handle Apple devices only.
    - `.skippedDifferentGPS(differences: [GPSDifference])` – Skipped due to a significant GPS mismatch detected.
    - `.failed(error: String)` – Processing failed due to an error.

 ## Configuration Properties

 ```swift
 static var DEBUG: Bool
 static var alwaysOverwriteGPS: Bool
 static var dryRunMode: Bool
 static var appleOnly: Bool
 static var silentlyIgnoreSkipped: Bool
 static var gpsToleranceDegrees: Double
 static var maxConcurrentTasks: Int

## Usage Example

import MediaFileProcessor

// Set configuration options as needed
MediaFileProcessor.DEBUG = true
MediaFileProcessor.dryRunMode = false      // No files will actually be written unless set to false
MediaFileProcessor.alwaysOverwriteGPS = false
MediaFileProcessor.appleOnly = true
MediaFileProcessor.silentlyIgnoreSkipped = true

let processor = MediaFileProcessor()

// List all supported media files in a directory
let directoryURL: URL = ... // Provide a directory path
let mediaFiles = processor.getMediaFilesFromDirectory(directoryURL)

// Read GPS and device data from the first media file (if available)
if let firstFile = mediaFiles.first {
    if let gps = processor.readGPSData(from: firstFile) {
        print("GPS Data:", gps)
    }
    if let device = processor.readDeviceData(from: firstFile) {
        print("Device Data:", device)
    }

    // Process the media file and its XMP
    Task {
        let result = await processor.processFile(firstFile, providedGPS: nil)
        switch result {
        case .updated(let changes):
            print("✅ XMP was updated for \(firstFile.lastPathComponent). Changes: \(changes)")
        case .alreadyCorrect:
            print("ℹ️ XMP already contained the correct metadata.")
        case .withinTolerance(let differences):
            print("🟦 Within tolerance: \(differences)")
        case .fileNotFound(let reason):
            print("❌ Media file or XMP sidecar not found: \(reason)")
        case .unsupportedFile(let reason):
            print("⚠️ Unsupported file format: \(reason)")
        case .skippedMissing(let reason):
            print("⏭️ Skipped missing: \(reason)")
        case .skippedNonApple(let device, let reason):
            let deviceStr = [device?.make, device?.model].compactMap { $0 }.joined(separator: " ")
            print("⏭️ Skipped (non-Apple) \(deviceStr.isEmpty ? "" : "(\(deviceStr))"): \(reason)")
        case .skippedDifferentGPS(let differences):
            print("⏭️ Skipped due to GPS mismatch: \(differences)")
        case .failed(let error):
            print("❌ Processing failed: \(error)")
        }
    }
}

// Note: If 'dryRunMode' is enabled, no changes will be written to disk.

