# MediaFileProcessor

`MediaFileProcessor` provides XMP-only GPS normalization for supported media files by ensuring numeric GPS tags have trailing hemisphere letters when missing, without creating new XMP sidecar files or performing tolerance-based GPS comparisons. It supports `.dng`, `.tif`, `.heic`, and `.heif` files and requires existing XMP sidecar files to operate.

## Supported Modules

- **GPSParser**  
  Parses numeric GPS strings and reference hemispheres. Detects trailing hemisphere letters and normalizes numeric GPS tags accordingly.

- **GPSData**  
  Represents latitude and longitude as signed decimal degrees.

- **ProcessingResult** and **ProcessingResultDetail**  
  Enum and types used to represent the outcome of processing a media file and its XMP, consumed by UI layers.

- **ScopedAccess**  
  Internal type that manages security-scoped resource access for folder and file URL permissions on macOS, defined inside `MediaFileProcessor`.

## Configuration

```swift
static var DEBUG: Bool = false
static var dryRunMode: Bool = false
static var silentlyIgnoreSkipped: Bool = false
static var maxConcurrentTasks: Int = 3

static var fatalErrorMessage: String? = nil
static var fatalErrorKind: FatalErrorKind? = nil

enum FatalErrorKind {
    case permissionDeniedXMP
    case insufficientDiskSpace
    case tmpFileTooSmall
    case backupFailed
    case atomicReplaceFailed
}

// Minimum free bytes required for safe write operations
static var minFreeBytesRequired: Int64 = 100_000_000

// Optional disk space provider closure; if nil, uses system default
static var diskSpaceProvider: ((URL) -> Int64?)? = nil

// Supported media file extensions (lowercased, without dot)
static var supportedExtensions: Set<String> = ["dng", "tif", "heif", "heic"]

// Test hooks for internal test use only
static var testForceBackupFailure: Bool = false
static var testGPSDataProvider: ((URL) -> GPSData?)? = nil

// Internal: Computed property to detect test mode environment
static var isTestMode: Bool {
    return ProcessInfo.processInfo.environment["XCTestConfigurationFilePath"] != nil
}
